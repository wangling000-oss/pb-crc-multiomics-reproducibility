library(TwoSampleMR)
library(data.table)
library(dplyr)
library(vroom)
library(VariantAnnotation)
library(gwasvcf)
library(gwasglue)
library(ieugwasr)
library(plinkbinr)
library(MRPRESSO)
library(readxl)

rm(list = ls())
gc()

# =========================================================
# Project paths
# Assumption: this script is located in MR/scripts/
# =========================================================
project_root <- normalizePath(file.path(getwd(), ".."), winslash = "/", mustWork = FALSE)

dir.create(file.path(project_root, "result"), showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(project_root, "plots"), showWarnings = FALSE, recursive = TRUE)

outcome_file <- file.path(project_root, "data", "outcome", "finngen_R10_C3_COLORECTAL_EXALLC.gz")
eqtl_file    <- file.path(project_root, "data", "exposure", "eQTLgenp5e-08_kb_10000_r2_0.01.xlsx")
symbol_file  <- file.path(project_root, "data", "exposure", "symbol.csv")
bfile_prefix <- file.path(project_root, "resources", "1kg.v3", "EUR")
plink_bin    <- plinkbinr::get_plink_exe()

# =========================================================
# Read input files
# =========================================================
outcome <- vroom::vroom(outcome_file, show_col_types = FALSE)
outcome <- as.data.frame(outcome, stringsAsFactors = FALSE)

eqtl <- readxl::read_xlsx(eqtl_file)
eqtl <- as.data.frame(eqtl, stringsAsFactors = FALSE)

symbol_df <- read.csv(symbol_file, check.names = FALSE, stringsAsFactors = FALSE)
list_Probe <- unique(symbol_df$NAME)

# =========================================================
# Optional filter for genome-wide significant eQTLs
# Uncomment only if needed and if it matches the manuscript
# =========================================================
# eqtl <- subset(eqtl, p < 5e-08)

# =========================================================
# Containers for main MR outputs
# =========================================================
result <- NULL
heterogeneity <- NULL
pleiotropy <- NULL
final_iv <- NULL

# =========================================================
# Main MR loop across genes/probes
# =========================================================
for (i in seq_along(list_Probe)) {
  current_probe <- list_Probe[i]
  message("Running probe ", i, "/", length(list_Probe), ": ", current_probe)
  
  exposure_raw <- subset(eqtl, Probe == current_probe)
  
  if (nrow(exposure_raw) == 0) {
    message("No exposure records found for ", current_probe, ". Skipping.")
    next
  }
  
  tryCatch({
    # Format exposure data
    exposure_dat <- format_data(
      exposure_raw,
      type = "exposure",
      phenotype_col = "Probe",
      snp_col = "SNP",
      beta_col = "b",
      se_col = "SE",
      eaf_col = "Freq",
      effect_allele_col = "A1",
      other_allele_col = "A2",
      pval_col = "p",
      chr_col = "Chr",
      pos_col = "BP"
    )
    exposure_dat$id.exposure <- exposure_dat$exposure
    
    # Local LD clumping using the EUR reference panel
    exposure_clump_ids <- ieugwasr::ld_clump(
      dplyr::tibble(
        rsid = exposure_dat$SNP,
        pval = exposure_dat$pval.exposure
      ),
      clump_kb = 1000,
      clump_r2 = 0.3,
      clump_p = 1,
      bfile = bfile_prefix,
      plink_bin = plink_bin,
      pop = "EUR"
    )
    
    exposure_clumped <- exposure_dat[exposure_dat$SNP %in% exposure_clump_ids$rsid, ]
    
    if (nrow(exposure_clumped) == 0) {
      message("No instruments retained after LD clumping for ", current_probe, ". Skipping.")
      next
    }
    
    # Extract matching outcome SNPs
    outcome_sub <- subset(outcome, rsids %in% exposure_clumped$SNP)
    
    if (nrow(outcome_sub) == 0) {
      message("No overlapping outcome SNPs found for ", current_probe, ". Skipping.")
      next
    }
    
    # Format outcome data
    outcome_dat <- format_data(
      dat = outcome_sub,
      type = "outcome",
      snp_col = "rsids",
      beta_col = "beta",
      pval_col = "pval",
      se_col = "sebeta",
      eaf_col = "af_alt",
      effect_allele_col = "alt",
      other_allele_col = "ref"
    )
    outcome_dat$id.outcome <- "FinnGen_R10_C3_COLORECTAL_EXALLC"
    
    # Harmonize exposure and outcome data
    mr_data <- harmonise_data(
      exposure_dat = exposure_clumped,
      outcome_dat = outcome_dat,
      action = 2
    )
    
    if (nrow(mr_data) == 0) {
      message("No harmonized SNPs retained for ", current_probe, ". Skipping.")
      next
    }
    
    # Save harmonized instruments
    mr_data$Probe <- current_probe
    final_iv <- rbind(final_iv, mr_data)
    
    # Main MR estimation
    mr_res <- mr(mr_data)
    mr_res <- generate_odds_ratios(mr_res)
    result <- rbind(result, mr_res)
    
    # Sensitivity analyses
    het <- mr_heterogeneity(mr_data)
    heterogeneity <- rbind(heterogeneity, het)
    
    if (nrow(mr_data) >= 2) {
      pleio <- mr_pleiotropy_test(mr_data)
      pleiotropy <- rbind(pleiotropy, pleio)
    }
    
  }, error = function(e) {
    message("Error for ", current_probe, ": ", conditionMessage(e))
  })
}

# =========================================================
# Save harmonized instruments
# =========================================================
write.csv(
  final_iv,
  file.path(project_root, "result", "MR_final_IV_SNP_list.csv"),
  row.names = FALSE
)

# =========================================================
# Filter main MR results for manuscript-style output
# Retain IVW and Wald ratio results, then apply additional filters
# =========================================================
res <- result[result$method %in% c("Wald ratio", "Inverse variance weighted"), , drop = FALSE]
res <- res[order(res$pval), , drop = FALSE]
res$FDR <- p.adjust(res$pval, method = "BH")

# Nominally significant results
res <- res[res$pval < 0.05, , drop = FALSE]

# Match sensitivity results to retained exposures
if (!is.null(heterogeneity) && nrow(heterogeneity) > 0 && nrow(res) > 0) {
  het <- heterogeneity[heterogeneity$id.exposure %in% res$id.exposure, , drop = FALSE]
} else {
  het <- heterogeneity
}

if (!is.null(pleiotropy) && nrow(pleiotropy) > 0 && nrow(res) > 0) {
  pleio <- pleiotropy[pleiotropy$id.exposure %in% res$id.exposure, , drop = FALSE]
} else {
  pleio <- pleiotropy
}

# Remove results with significant heterogeneity or pleiotropy
id_1 <- character(0)
id_2 <- character(0)

if (!is.null(het) && nrow(het) > 0) {
  id_1 <- het$id.exposure[het$Q_pval < 0.05]
}

if (!is.null(pleio) && nrow(pleio) > 0) {
  id_2 <- pleio$id.exposure[pleio$pval < 0.05]
}

exclude_ids <- unique(c(id_1, id_2))

if (length(exclude_ids) > 0 && !is.null(res) && nrow(res) > 0) {
  res <- res[!res$id.exposure %in% exclude_ids, , drop = FALSE]
}
if (length(exclude_ids) > 0 && !is.null(het) && nrow(het) > 0) {
  het <- het[!het$id.exposure %in% exclude_ids, , drop = FALSE]
}
if (length(exclude_ids) > 0 && !is.null(pleio) && nrow(pleio) > 0) {
  pleio <- pleio[!pleio$id.exposure %in% exclude_ids, , drop = FALSE]
}

# =========================================================
# Save main MR result tables
# =========================================================
write.csv(
  res,
  file.path(project_root, "result", "MR_result_eqtlgen.csv"),
  row.names = FALSE
)

write.csv(
  het,
  file.path(project_root, "result", "MR_heterogeneity_eqtlgen.csv"),
  row.names = FALSE
)

write.csv(
  pleio,
  file.path(project_root, "result", "MR_pleiotropy_eqtlgen.csv"),
  row.names = FALSE
)

# =========================================================
# HMOX1 LD sensitivity analysis
# =========================================================
gene <- "ENSG00000100292"
ld_r2_list <- c(0.3, 0.1, 0.01)
sens_res <- data.frame()

exposure_hmox1_raw <- subset(eqtl, Probe == gene)

if (nrow(exposure_hmox1_raw) == 0) {
  stop("No exposure data found for HMOX1 / ENSG00000100292.")
}

exposure_hmox1 <- format_data(
  exposure_hmox1_raw,
  type = "exposure",
  phenotype_col = "Probe",
  snp_col = "SNP",
  beta_col = "b",
  se_col = "SE",
  eaf_col = "Freq",
  effect_allele_col = "A1",
  other_allele_col = "A2",
  pval_col = "p",
  chr_col = "Chr",
  pos_col = "BP"
)
exposure_hmox1$id.exposure <- exposure_hmox1$exposure

for (r2_use in ld_r2_list) {
  exposure_hmox1_ids <- ieugwasr::ld_clump(
    dplyr::tibble(
      rsid = exposure_hmox1$SNP,
      pval = exposure_hmox1$pval.exposure
    ),
    clump_kb = 1000,
    clump_r2 = r2_use,
    clump_p = 1,
    bfile = bfile_prefix,
    plink_bin = plink_bin,
    pop = "EUR"
  )
  
  exposure_hmox1_clumped <- exposure_hmox1[exposure_hmox1$SNP %in% exposure_hmox1_ids$rsid, ]
  
  if (nrow(exposure_hmox1_clumped) == 0) {
    next
  }
  
  outcome_hmox1 <- subset(outcome, rsids %in% exposure_hmox1_clumped$SNP)
  
  if (nrow(outcome_hmox1) == 0) {
    next
  }
  
  outcome_hmox1 <- format_data(
    outcome_hmox1,
    type = "outcome",
    snp_col = "rsids",
    beta_col = "beta",
    pval_col = "pval",
    se_col = "sebeta",
    eaf_col = "af_alt",
    effect_allele_col = "alt",
    other_allele_col = "ref"
  )
  outcome_hmox1$id.outcome <- "FinnGen_R10_C3_COLORECTAL_EXALLC"
  
  mr_data_hmox1_tmp <- harmonise_data(
    exposure_dat = exposure_hmox1_clumped,
    outcome_dat = outcome_hmox1,
    action = 2
  )
  
  if (nrow(mr_data_hmox1_tmp) == 0) {
    next
  }
  
  mr_res_hmox1_tmp <- mr(mr_data_hmox1_tmp)
  mr_res_hmox1_tmp <- generate_odds_ratios(mr_res_hmox1_tmp)
  
  ivw <- subset(mr_res_hmox1_tmp, method == "Inverse variance weighted")
  
  if (nrow(ivw) == 0) {
    next
  }
  
  sens_res <- rbind(
    sens_res,
    data.frame(
      Gene = gene,
      LD_r2 = r2_use,
      nsnp = ivw$nsnp,
      OR = ivw$or,
      OR_l = ivw$or_lci95,
      OR_u = ivw$or_uci95,
      P = ivw$pval,
      stringsAsFactors = FALSE
    )
  )
}

write.csv(
  sens_res,
  file.path(project_root, "result", "Table_S4_LD_sensitivity_HMOX1.csv"),
  row.names = FALSE
)

# =========================================================
# Rebuild HMOX1-specific harmonized data for plotting
# Fixed at r2 = 0.3 to match the main HMOX1 sensitivity setting
# =========================================================
exposure_hmox1_ids <- ieugwasr::ld_clump(
  dplyr::tibble(
    rsid = exposure_hmox1$SNP,
    pval = exposure_hmox1$pval.exposure
  ),
  clump_kb = 1000,
  clump_r2 = 0.3,
  clump_p = 1,
  bfile = bfile_prefix,
  plink_bin = plink_bin,
  pop = "EUR"
)

exposure_hmox1_clumped <- exposure_hmox1[exposure_hmox1$SNP %in% exposure_hmox1_ids$rsid, ]

outcome_hmox1 <- subset(outcome, rsids %in% exposure_hmox1_clumped$SNP)
outcome_hmox1 <- format_data(
  outcome_hmox1,
  type = "outcome",
  snp_col = "rsids",
  beta_col = "beta",
  pval_col = "pval",
  se_col = "sebeta",
  eaf_col = "af_alt",
  effect_allele_col = "alt",
  other_allele_col = "ref"
)
outcome_hmox1$id.outcome <- "FinnGen_R10_C3_COLORECTAL_EXALLC"

mr_data_hmox1 <- harmonise_data(
  exposure_dat = exposure_hmox1_clumped,
  outcome_dat = outcome_hmox1,
  action = 2
)

if (nrow(mr_data_hmox1) == 0) {
  stop("No harmonized HMOX1 instruments retained for plotting.")
}

mr_res_hmox1 <- mr(mr_data_hmox1)
mr_res_hmox1 <- generate_odds_ratios(mr_res_hmox1)

# =========================================================
# HMOX1 plots
# =========================================================
scatter_plot <- mr_scatter_plot(mr_res_hmox1, mr_data_hmox1)

png(
  file.path(project_root, "plots", paste0("scatter_", gene, ".png")),
  width = 800,
  height = 600
)
print(scatter_plot[[1]])
dev.off()

leaveoneout_res <- mr_leaveoneout(mr_data_hmox1)
loo_plot <- mr_leaveoneout_plot(leaveoneout_res)

png(
  file.path(project_root, "plots", paste0("leaveoneout_", gene, ".png")),
  width = 800,
  height = 600
)
print(loo_plot[[1]])
dev.off()

res_single <- mr_singlesnp(mr_data_hmox1)
funnel_plot <- mr_funnel_plot(res_single)

png(
  file.path(project_root, "plots", paste0("funnel_", gene, ".png")),
  width = 800,
  height = 600
)
print(funnel_plot[[1]])
dev.off()

# =========================================================
# Session info for reproducibility
# =========================================================
writeLines(
  capture.output(sessionInfo()),
  file.path(project_root, "result", "sessionInfo_mr.txt")
)