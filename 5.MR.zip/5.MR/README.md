# OUTPUT_INVENTORY

This file provides an inventory of the regenerated outputs for the Mendelian randomization (MR) module, including which script generates which output file and how each output relates to the reproducibility workflow.

## Main input files

### Exposure
- `data/exposure/eQTLgenp5e-08_kb_10000_r2_0.01.xlsx`  
  Exposure summary table used for instrument extraction and MR analysis.

- `data/exposure/symbol.csv`  
  Gene-symbol mapping file used to annotate the MR results.

### Outcome
- `data/outcome/finngen_R10_C3_COLORECTAL_EXALLC.gz`  
  Outcome GWAS summary statistics for colorectal cancer.

### LD reference panel
- `resources/1kg.v3/EUR.bed`
- `resources/1kg.v3/EUR.bim`
- `resources/1kg.v3/EUR.fam`

These files are used for local LD clumping.

---

## Main workflow

### `scripts/mr_sensitivity.R`

**Purpose:**  
Run the main MR analysis, including instrument preparation, local LD clumping, harmonization, MR estimation, heterogeneity testing, pleiotropy testing, and HMOX1-focused LD sensitivity analysis.

**Main inputs:**  
- `data/exposure/eQTLgenp5e-08_kb_10000_r2_0.01.xlsx`
- `data/exposure/symbol.csv`
- `data/outcome/finngen_R10_C3_COLORECTAL_EXALLC.gz`
- `resources/1kg.v3/EUR.bed`
- `resources/1kg.v3/EUR.bim`
- `resources/1kg.v3/EUR.fam`

**Generated outputs in `result/`:**  
- `MR_final_IV_SNP_list.csv`
- `MR_result_eqtlgen.csv`
- `MR_heterogeneity_eqtlgen.csv`
- `MR_pleiotropy_eqtlgen.csv`
- `Table_S4_LD_sensitivity_HMOX1.csv`

**Generated outputs in `plots/`:**  
- `scatter_ENSG00000100292.png`
- `leaveoneout_ENSG00000100292.png`
- `funnel_ENSG00000100292.png`

**Notes:**  
- `MR_final_IV_SNP_list.csv` records the final instrument SNPs after filtering and local LD clumping.  
- `MR_result_eqtlgen.csv` contains the main MR estimates.  
- `MR_heterogeneity_eqtlgen.csv` contains the heterogeneity test results.  
- `MR_pleiotropy_eqtlgen.csv` contains the pleiotropy test results.  
- `Table_S4_LD_sensitivity_HMOX1.csv` documents the HMOX1 LD sensitivity analysis across different clumping thresholds.  
- The three plot files correspond to the HMOX1-focused visualization outputs.

---

## Summary table

| Script | Main output files | Role in workflow |
|---|---|---|
| `scripts/mr_sensitivity.R` | `MR_final_IV_SNP_list.csv`, `MR_result_eqtlgen.csv`, `MR_heterogeneity_eqtlgen.csv`, `MR_pleiotropy_eqtlgen.csv`, `Table_S4_LD_sensitivity_HMOX1.csv`, `scatter_ENSG00000100292.png`, `leaveoneout_ENSG00000100292.png`, `funnel_ENSG00000100292.png` | Main MR analysis and HMOX1 sensitivity analysis |

---

## Relationship to the manuscript

The outputs in this module support the Mendelian randomization component of the manuscript.  
The main result tables document the MR effect estimates and sensitivity statistics, while the HMOX1-specific table and plots document the LD sensitivity analysis retained in the reproducibility package.