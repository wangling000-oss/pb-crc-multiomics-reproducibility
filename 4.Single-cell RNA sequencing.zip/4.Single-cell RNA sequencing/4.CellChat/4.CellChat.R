setwd("XXX")
library(Seurat)
library(tidyverse)
library(Matrix)
library(stringr)
library(dplyr)
library(Seurat)
library(patchwork)
library(ggplot2)
library(SingleR)
library(CCA)
library(clustree)
library(cowplot)
library(monocle)
library(tidyverse)
library(SCpubr)
library(harmony)
library(plyr)
library(randomcoloR)
library(CellChat)

load("yjsl_Type.rda")

head(yjsl@meta.data)


# CellChat
cellchat = createCellChat(object = yjsl,
                          group.by = "cellType") # Define grouping by group.by



# Display the current cell groups
levels(cellchat@idents) 
# # Number of cells in each subgroup
# group <- as.numeric(table(cellchat@idents))

# Set the ligand-receptor interaction database
CellChatDB <- CellChatDB.human # If using mouse data, use the built-in "CellChatDB.mouse" database

showDatabaseCategory(CellChatDB)
# Human data include 61.8% paracrine/autocrine signaling interactions,
# 21.7% extracellular matrix (ECM)-receptor interactions,
# and 16.5% cell-cell contact interactions


unique(CellChatDB$interaction$annotation)

# If you want to use the full database for CellChat analysis, do not use subsetDB;
# simply assign cellchat@DB <- CellChatDB directly.
# CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") 
# # Set the used database in the object
# cellchat@DB <- CellChatDB.use
# Use Secreted Signaling for cell-cell communication analysis
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling")
cellchat@DB <- CellChatDB.use 


###################### Preprocess the expression data ######################

## This step is necessary even if using the whole database
cellchat <- subsetData(cellchat)
# Set according to the configuration
future::plan("multisession", workers = 4)
library(presto)


{
  # Identify overexpressed genes (slow)
  cellchat <- identifyOverExpressedGenes(cellchat)
  # Identify overexpressed ligand-receptor pairs
  cellchat <- identifyOverExpressedInteractions(cellchat)
}
{
  # Project ligands and receptors onto the PPI network (slow)
  # The projectData function projects the expression values of ligand-receptor pairs onto the PPI network.
  # This step is optional; if performed, the results can be viewed in data.project
  # cellchat <- projectData(cellchat, PPI.human) # v1 syntax
  
  # Optional: make sure PPI.human exists in the environment
  data("PPI.human")   # If not found, use PPI.human <- CellChat::PPI.human
  
  cellchat <- smoothData(cellchat, adj = PPI.human) # v2 syntax
  
  ########## After the data and ligand-receptor database are ready, infer interactions between cell types based on expression values ##########
  ## Infer the cell-cell communication network (very slow, ~5 minutes)
  cellchat <- computeCommunProb(cellchat, raw.use = TRUE) # raw.use = TRUE means using raw data instead of the results after projectData
  
  ## Official website code (when population.size = TRUE, CellChat considers the effect of cell proportions in each cell group during probability calculation)
  # cellchat <- computeCommunProb(cellchat, raw.use = TRUE, population.size = TRUE) 
  
  ### If there are only a few cells in a specific cell group, filter out the communications involving that group (very slow, ~5 minutes)
  cellchat <- filterCommunication(cellchat, min.cells = 5)
}

# Recommended to save the object
save(cellchat,file = "cellchat.rda")
load("cellchat.rda")


## Extract and save results
df.net <- subsetCommunication(cellchat)
head(df.net)
write.csv(df.net,"df.net.csv")

# df.net1 <- subsetCommunication(cellchat,slot.name = "netP")
## View cell communication groups ###
levels(cellchat@idents)

######## Three ways to build the network ########
## By index
df.net1 <- subsetCommunication(cellchat, sources.use = c(2), targets.use = c(8)) 
head(df.net1)
## By name
df.net2 <- subsetCommunication(cellchat, sources.use = c("Monocytes/Macrophages"), targets.use = c("Tumor Epithelial Cells" ,"Tumor Epithelial Cells")) 
head(df.net2)
## By pathway
df.net3 <- subsetCommunication(cellchat, signaling = c("SPP1"))
head(df.net3)

############ Calculate cell-cell communication #####
# Use computeCommunProbPathway to calculate communication results for all ligand-receptor interactions in each signaling pathway;
# the results are stored in net and netP
cellchat <- computeCommunProbPathway(cellchat)
## Use aggregateNet to calculate the aggregated cell communication results between cell types
cellchat <- aggregateNet(cellchat)


########## Visualization ##########

########## 1. Communication results between cell types ##########
########## Number of interactions (left) and interaction strength (right)

groupSize <- as.numeric(table(cellchat@idents))
par(mfrow = c(1,2), xpd=TRUE)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, 
                 weight.scale = T, 
                 label.edge= F, title.name = "Number of interactions")
netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, 
                 weight.scale = T, 
                 label.edge= F, title.name = "Interaction weights/strength")

# Left plot: the size of each colored circle around the periphery indicates the number of cells;
# larger circles mean more cells.
# Cells emitting arrows express ligands, and the cells pointed to by arrows express receptors.
# The more ligand-receptor pairs there are, the thicker the line.
# Right plot: interaction probability or strength value (strength is the sum of probability values)

## Another visualization method
p3 <- netVisual_heatmap(cellchat)
p3
p4 <- netVisual_heatmap(cellchat, measure = "weight")
p4
p3 + p4

########## Show separately
# Flexibly adjust mfrow = c(2,3) according to the number of cell types
mat <- cellchat@net$weight

### Another way
{
  mat <- cellchat@net$count
  par(mfrow = c(2,5), xpd=TRUE)
  for (i in 1:nrow(mat)) {
    mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
    mat2[i, ] <- mat[i, ]
    netVisual_circle(mat2, vertex.weight = groupSize, weight.scale = T, edge.weight.max = max(mat), title.name = rownames(mat)[i])
  }
}
########## Visualization of a single signaling pathway

# Show which pathways are currently available
cellchat@netP$pathways
# Select the pathway of interest for visualization
pathways.show <- c("SPP1") 

# Check the current cell type order
levels(cellchat@idents) 
# Specify target cell types through vertex.receiver
## The selected cell groups are on the left, and the remaining cell groups are on the right
vertex.receiver = c(1,2) 

## Hierarchy plot
netVisual_aggregate(cellchat, signaling = "TGFb", 
                    vertex.receiver = vertex.receiver,layout="hierarchy")
# In the hierarchy plot, solid circles and hollow circles represent sources and targets, respectively.
# The size of the circles is proportional to the number of cells in each cell group.
# Thicker lines indicate stronger interaction signals.

## Circle plot
par(mfrow=c(1,1))
netVisual_aggregate(cellchat, signaling ="TGFb", layout = "circle")

## Chord plot
par(mfrow=c(1,1))
netVisual_aggregate(cellchat, signaling ="TGFb", layout = "chord", vertex.size = groupSize)

## Heatmap
par(mfrow=c(1,1))
netVisual_heatmap(cellchat, signaling = "SPP1", color.heatmap = "Reds")

########## Bubble plot ##############################
# Specify ligand-receptor source and target groups using sources.use and targets.use
levels(cellchat@idents)
netVisual_bubble(cellchat, sources.use = 2, 
                 targets.use = c(1,3,4,5,6,7,8,9,10), remove.isolate = FALSE)

## Specify source-target cell types and signaling pathways
cellchat@netP$pathways 
netVisual_bubble(cellchat, sources.use = c(2,4), targets.use = c(3,5,6,7), 
                 signaling = c("TGFb","SPP1"), remove.isolate = FALSE)


# Display the expression of all genes in a specific signaling pathway (e.g., SPP1) across cell groups
plotGeneExpression(cellchat, signaling = "SPP1")

# =========================
# Save CellChat intermediate tables for figure reproducibility
# =========================

# E. Number of interactions matrix
net_count <- as.data.frame(as.table(cellchat@net$count))
colnames(net_count) <- c("source", "target", "interaction_count")
write.csv(net_count, "cellchat_net_count.csv", row.names = FALSE)

# F. Interaction weight/strength matrix
net_weight <- as.data.frame(as.table(cellchat@net$weight))
colnames(net_weight) <- c("source", "target", "interaction_weight")
write.csv(net_weight, "cellchat_net_weight.csv", row.names = FALSE)

# Cell group sizes used in circle plots
group_size <- as.data.frame(table(cellchat@idents))
colnames(group_size) <- c("cellType", "n_cells")
write.csv(group_size, "cellchat_group_size.csv", row.names = FALSE)
