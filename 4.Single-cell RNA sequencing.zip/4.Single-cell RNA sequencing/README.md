# Single-cell RNA sequencing reproducibility

This directory contains the reproducibility materials for the single-cell RNA sequencing (scRNA-seq) and CellChat analyses based on the public dataset GSE144735.

## Public data source

The raw public input file used in this module is:

- `GSE144735.txt`

This file was downloaded from the GEO accession **GSE144735**.  
For downstream analysis in this reproducibility package, `GSE144735.txt` was converted to:

- `GSE144735.csv`

The downstream scripts read `GSE144735.csv` as the main expression input file.

## Workflow overview

The single-cell analysis workflow is organized into four steps:

1. Reading and conversion of the public single-cell file  
2. Batch effect correction and dimensionality reduction  
3. Single-cell annotation and marker visualization  
4. CellChat analysis

---

## 1. Reading single-cell files

**Script:**  
`1.Reading single-cell files (csv).R`

**Purpose:**  
This script reads the downloaded public file `GSE144735.txt` and converts it into `GSE144735.csv` for downstream processing.

**Input:**  
- `GSE144735.txt`

**Output:**  
- `GSE144735.csv`

---

## 2. Batch effect correction and dimensionality reduction

**Script:**  
`2.Batch effect correction and dimensionality reduction.R`

**Purpose:**  
This script reads `GSE144735.csv`, performs preprocessing, batch effect correction, clustering, and dimensionality reduction, and prepares the processed single-cell object for downstream annotation.

**Input:**  
- `GSE144735.csv`

**Output:**  
- processed single-cell object used in the annotation step

**Note:**  
The UMAP embedding is generated in this step and then carried forward to the downstream annotation workflow.

---

## 3. Single-cell annotation

**Script:**  
`3.Single-cell annotation/3.Single-cell annotation.R`

**Purpose:**  
This script performs cell-type annotation and generates the main annotation-related visualization source tables.

**Main input:**  
- processed single-cell object from Step 2

**Generated files:**  
- `3.Single-cell annotation/af2025.rds`  
- `3.Single-cell annotation/yjsl_Type.rda`  
- `3.Single-cell annotation/umap_coordinates.csv`  
- `3.Single-cell annotation/annotation_dotplot_table.csv`  
- `3.Single-cell annotation/selected_gene_dotplot_table.csv`  
- `3.Single-cell annotation/featureplot_HMOX1_table.csv`

**Notes:**  
- `af2025.rds` is the processed single-cell object used for annotation-related analyses.  
- `yjsl_Type.rda` is the annotated single-cell object used for downstream CellChat analysis.  
- `umap_coordinates.csv` stores the UMAP coordinates corresponding to the annotated cells.  
- `annotation_dotplot_table.csv` stores the source data for the annotation marker dot plot.  
- `selected_gene_dotplot_table.csv` stores the source data for the selected-gene dot plot.  
- `featureplot_HMOX1_table.csv` stores the source data for the HMOX1 feature plot.

---

## 4. CellChat

**Script:**  
`4.CellChat/4.CellChat.R`

**Purpose:**  
This script reads the annotated single-cell object and performs CellChat-based cell-cell communication analysis.

**Main input:**  
- `3.Single-cell annotation/yjsl_Type.rda`

**Generated files:**  
- `4.CellChat/cellchat.rda`  
- `4.CellChat/cellchat_group_size.csv`  
- `4.CellChat/cellchat_net_count.csv`  
- `4.CellChat/cellchat_net_weight.csv`

**Notes:**  
- `cellchat.rda` is the saved CellChat analysis object.  
- `cellchat_group_size.csv` stores the group-size information used in CellChat visualization.  
- `cellchat_net_count.csv` stores the interaction count matrix used for CellChat network visualization.  
- `cellchat_net_weight.csv` stores the interaction weight matrix used for CellChat network visualization.

---

## Saved intermediate tables for figure traceability

Intermediate tables corresponding to the main single-cell and CellChat visualization panels were saved as CSV files for traceability and regeneration. These include:

- `umap_coordinates.csv`
- `annotation_dotplot_table.csv`
- `selected_gene_dotplot_table.csv`
- `featureplot_HMOX1_table.csv`
- `cellchat_group_size.csv`
- `cellchat_net_count.csv`
- `cellchat_net_weight.csv`

These saved tables document the data underlying the main scRNA-seq and CellChat visualizations in the reproducibility package.

## Relationship to the manuscript figures

The single-cell and CellChat analyses support the scRNA-seq-related figure panels in the manuscript.  
The saved CSV tables correspond to the main visualization panels and were retained to make the figure-generation inputs explicit and traceable.