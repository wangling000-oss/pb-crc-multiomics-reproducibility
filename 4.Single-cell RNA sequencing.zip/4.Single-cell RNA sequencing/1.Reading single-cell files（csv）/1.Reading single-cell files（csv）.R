library(limma)
library(dplyr)
library(Seurat)
library(patchwork)
library(ggplot2)
library(SingleR)
library(CCA)
library(clustree)
library(cowplot)
library(monocle)
library(tidyverse)
#Matrix reading in
rt=read.csv(file = "GSE144735.csv",header = T,sep = ",",row.names = 1)
data=rt
#Create a Seurat object
yjsl<-CreateSeuratObject(counts =data, 
                       project = "SeuratObject", 
                       min.cells = 3,#How many cells must each feature be expressed in at a minimum
                       min.features = 200)#How many features were detected in at least one cell
################质控可视化################

#Calculate the percentage of mitochondrial genes
yjsl[["percent.mt"]] <- PercentageFeatureSet(yjsl, pattern = "^MT-")
#Calculate the percentage of ribosomal genes
yjsl[["percent.rb"]] <- PercentageFeatureSet(yjsl, pattern = "^RP")
#（nFeature_RNA）（nCount_RNA（percent.mt）
VlnPlot(yjsl, features = c("nFeature_RNA", "nCount_RNA","percent.mt"), 
        ncol = 3)#,pt.size = 0

##nCount represents the number of molecules detected in each cell.
## nFeature represents the number of genes detected in each cell.
### If there are abnormal outlier cells among these two, it indicates that the cell might be a double cell or a multi-cell (for quality control purposes, to eliminate outliers).
## Draw a scatter plot to compare the relationships between different features.
plot2 <- FeatureScatter(yjsl, feature1 = "nCount_RNA", feature2 = "percent.rb")+ RotatedAxis()
plot2
plot3 <- FeatureScatter(yjsl, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")+ RotatedAxis()
plot3

plot2 + plot3
###Filtering genes
sub1 <- yjsl$nCount_RNA >= 1000 ## 
sub2 <- yjsl$nFeature_RNA >= 200 & yjsl$nFeature_RNA <= 10000# 
sub3 <- yjsl$percent.mt <= 20# 
sub4<-yjsl$percent.rb<= 20 # 
sub <-sub2 & sub3 & sub4 # 
yjsl <- yjsl[, sub]# 


VlnPlot(yjsl, features = c("nFeature_RNA", "nCount_RNA","percent.mt"), 
        ncol = 3)
#### Official website
## Filter out cells with more than 2,500 or fewer than 200 genes
# Filter out cells with a mitochondrial gene percentage greater than 5%
yjsl <- subset(yjsl, subset = nFeature_RNA > 200 & nFeature_RNA < 2500 & percent.mt < 5)

##Save for subsequent analysis
saveRDS(yjsl,"af.rds")
