
library(Seurat)
library(tidyverse)
library(Matrix)
library(stringr)
library(dplyr)
library(Seurat)
library(patchwork)
library(ggplot2)
library(SingleR)
library(CCA)
library(clustree)
library(cowplot)
library(monocle)
library(tidyverse)
library(SCpubr)
#BiocManager::install("UCell")
library(UCell)
library(AUCell)
library(decoupleR)
library(singscore)
#devtools::install_github("chuiqin/irGSEA", force =T)
library(irGSEA)##
library(GSVA)
library(GSEABase)
library(harmony)
library(plyr)
library(randomcoloR)
library(CellChat)

###Start the official operation###
yjsl=readRDS("af.rds")

#######LogNormalize#######
yjsl <- NormalizeData(yjsl, normalization.method = "LogNormalize", 
                      scale.factor = 10000)

#######Identification of high-variable genes#######

yjsl <- FindVariableFeatures(yjsl, selection.method = "vst", nfeatures = 2000)

#top 15
top15 <- head(VariableFeatures(yjsl), 15)
top15

##Display high-variable genes
plot1 <- VariableFeaturePlot(yjsl, pt.size = 2, raster = T)
plot1
plot2 <- LabelPoints(plot = plot1, points = top15, 
                     xnudge = 0,
                     ynudge = 0)
plot2 
plot1 + plot2

######Scaling
{
all.genes <- rownames(yjsl)
yjsl <- ScaleData(yjsl, features = all.genes)
}
####Formal dimensionality reduction###
yjsl<- RunPCA(yjsl, features = VariableFeatures(object =yjsl)) 
#visualization
#VizDimReduction
VizDimLoadings(yjsl, dims = 1:2, reduction = "pca")
# DimPlot
DimPlot(yjsl, reduction = "pca")
#DimHeatmap
DimHeatmap(yjsl, dims = 1:15, cells = 500, balanced = TRUE)
#ElbowPlot
ElbowPlot(yjsl, ndims=20, reduction="pca") 

########harmony########################
yjsl <- RunHarmony(yjsl, group.by.vars = "Type")



#######Identification of high-variable genes#######

yjsl <- FindVariableFeatures(yjsl, selection.method = "vst", nfeatures = 2000)

#top 15
top15 <- head(VariableFeatures(yjsl), 15)
top15

##Display high-variable genes
plot1 <- VariableFeaturePlot(yjsl, pt.size = 2, raster = T)
plot1
plot2 <- LabelPoints(plot = plot1, points = top15, 
                     xnudge = 0,
                     ynudge = 0)
plot2 
plot1 + plot2

######Scaling
all.genes <- rownames(yjsl)
yjsl <- ScaleData(yjsl, features = all.genes)

####Formal dimensionality reduction###
yjsl<- RunPCA(yjsl, features = VariableFeatures(object =yjsl)) 
#visualization
#VizDimReduction
VizDimLoadings(yjsl, dims = 1:2, reduction = "pca")
# DimPlot
DimPlot(yjsl, reduction = "pca")
#DimHeatmap
DimHeatmap(yjsl, dims = 1:15, cells = 500, balanced = TRUE)

#ElbowPlot
ElbowPlot(yjsl, ndims=20, reduction="pca") 



########Determine the dimensions and cell clustering########
#PC
PC=1:10
###Group the cells according to the appropriate dimension as mentioned in the previous step.
yjsl <- FindNeighbors(yjsl, dims = PC)
#resolution
yjsl <- FindClusters(yjsl, resolution =seq(0.2,1.2,0.1))
clustree(yjsl)

yjsl <- FindClusters(yjsl, resolution =0.5)##记住这个维度
###UMAP
yjsl <- RunUMAP(yjsl, dims = PC)
#visualization
DimPlot(yjsl, reduction = "umap", label = T,repel = T)


###tSNE
yjsl = RunTSNE(yjsl, dims = PC)
embed_tsne <- Embeddings(yjsl, 'tsne')
DimPlot(yjsl, reduction = "tsne") 


###Take a general look at the situation###
# How many types to check
table(yjsl@meta.data$seurat_clusters)
#Only retain the genes with significantly increased expression differences
markers <- FindAllMarkers(yjsl, only.pos = TRUE, 
                          min.pct = 0.25, 
                          logfc.threshold = 0.25)
write.csv(markers,file = "cluster.csv")
head(markers)

##Save for subsequent analysis
saveRDS(yjsl,"af2025.rds")














