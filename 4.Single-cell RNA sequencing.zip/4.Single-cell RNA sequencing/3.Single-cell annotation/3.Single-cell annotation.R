setwd("XXX")
library(Seurat)
library(tidyverse)
library(Matrix)
library(stringr)
library(dplyr)
library(Seurat)
library(patchwork)
library(ggplot2)
library(CCA)
library(clustree)
library(cowplot)
library(monocle)
library(tidyverse)
library(SCpubr)
library(harmony)
library(plyr)
library(randomcoloR)
#install.packages("/Users/zhangzhenhu/Desktop/单细胞注释_人工/scRNAtoolVis_0.1.0.tar.gz", repos=NULL, type="source")
#devtools::install_github('junjunlab/scRNAtoolVis')
library(scRNAtoolVis)

yjsl=readRDS("af2025.rds")



######common type of marker gene################
# T Cells (CD3D, CD3E, CD8A)
# 
# B cells (CD19, CD79A, MS4A1 [CD20])
# 
# Plasma cells (IGHG1, MZB1, SDC1, CD79A)
# 
# Monocytes and macrophages (CD68, CD163, CD14)
# 
# NK Cells (FGFBP2, FCG3RA, CX3CR1)
# 
# Photoreceptor cells (RCVRN)
# 
# Fibroblasts (FGF7, MME)
# 
# Endothelial cells (PECAM1, VWF)
# 
# epi or tumor (EPCAM, KRT19, PROM1, ALDH1A1, CD24)
# 
# immune (CD45+,PTPRC)
# 
# epithelial/cancer (EpCAM+,EPCAM)
# 
# stromal (CD10+,MME,fibo or CD31+,PECAM1,endo)
# 
# mast cells( TPSAB1 and TPSB2 )
# 
# naive B cells(MS4A1 (CD20), CD19, CD22, TCL1A, and CD83)
# 
# plasma B cells(CD38, TNFRSF17 (BCMA), and IGHG1/IGHG4 





yjsl <- FindClusters(yjsl, resolution = 0.7)##Remember the same number as the resolution mentioned above

genes <- list("B/Plasma cells" = c("IGKC","JCHAIN","MZB1","XBP1"),
              "Monocytes/Macrophages"= c("CD68", "FCGR3A","LST1"),
              "Endothelial" = c("CLDN5", "ENG","FLT1"),
              "Fibroblasts" = c("COL1A1", "DCN","MMP2","ACTA2"),
              "Enterocyte" = c("CA1", "CA2"),
              "Epithelial" = c("CLDN3", "EPCAM","KRT18"),
              "Pericytes/SMC" = c("ACTA2", "MCAM","MYH11"),
              "T cells" = c("CD3D", "CD3E","TRAC","CD8A", "CD8B","GZMB"),
              "Mast"=c("CPA3","KIT"),
              "Enteric Glial Cells"=c("S100B","PLP1"),
              "Tumor Epithelial Cellss"=c("MMP7","CEACAM6")
            
)


do_DotPlot(sample = yjsl,features = genes,dot.scale = 10,colors.use = c("yellow","red"),legend.length = 50,
           legend.framewidth = 2, font.size =10)

DotPlot(yjsl, features = genes,cols = "RdYlBu") +
  RotatedAxis()

features_vec <- unique(unlist(genes))
features_vec <- features_vec[features_vec %in% rownames(yjsl)]

p_basic <- DotPlot(yjsl, features = features_vec, assay = "RNA") + RotatedAxis()
p_basic

p_basic <- DotPlot(yjsl, features = features_vec, assay = "RNA", cols = c("yellow", "red")) + RotatedAxis()
p_basic


#if(!requireNamespace("cowplot", quietly = TRUE)) install.packages("cowplot")
#if(!requireNamespace("viridis", quietly = TRUE)) install.packages("viridis")
library(ggplot2)
library(cowplot)
library(viridis)


features_vec <- unique(unlist(genes))
features_vec <- features_vec[features_vec %in% rownames(yjsl)]

# DotPlot 
p_tmp <- DotPlot(yjsl, features = features_vec, assay = "RNA")
dot_data <- p_tmp$data

# feature -> group 
feature2group <- data.frame(
  feature = unlist(genes),
  group = rep(names(genes), lengths(genes)),
  stringsAsFactors = FALSE
)

dot_data2 <- merge(dot_data, feature2group, by.x = "features.plot", by.y = "feature", all.x = TRUE)

cluster_levels <- levels(Idents(yjsl))

label_df <- data.frame(group = names(genes), x = seq_along(names(genes)), y = 1, stringsAsFactors = FALSE)

top_labels <- ggplot(label_df, aes(x = x, y = y, label = group)) +
  geom_text(size = 5, fontface = "bold") +
  facet_wrap(~ group, nrow = 1, scales = "free_x", strip.position = "top") +
  theme_void() +
  theme(
    strip.text = element_blank(),
    panel.spacing = unit(0, "lines"),
    plot.margin = unit(c(0, 0, 0, 0), "lines")
  )

main_plot <- ggplot(dot_data2, aes(x = id, y = features.plot)) +
  geom_point(aes(size = pct.exp, color = avg.exp.scaled)) +
  scale_size(range = c(0, 8), name = "pct.exp") +
  scale_color_viridis_c(option = "C", name = "avg.exp.scaled") +   # viridis 色盘
  facet_grid(rows = vars(group), scales = "free_y", space = "free_y") +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 9),
    axis.title = element_blank(),
    strip.text.y = element_blank(),    #  strip
    panel.spacing = unit(0.02, "lines"),
    plot.margin = unit(c(0, 5, 0, 5), "pt")  # 
  ) +
  ylab(NULL) + xlab(NULL)


final_plot <- plot_grid(top_labels, main_plot, ncol = 1, rel_heights = c(0.08, 1))
print(final_plot)


ggsave("dotplot_grouped_toplabels.png", final_plot, width = 14, height = 10, dpi = 300)
#
ggsave("dotplot_grouped_toplabels.pdf", final_plot, width = 14, height = 10)


#Manual annotation
table(yjsl@active.ident)
ann.ids <- c("B/Plasma cells",              #cluster0
             "Monocytes/Macrophages",      #cluster1
             "Endothelial",      #
             "Fibroblasts",
             "Fibroblasts",
             "Monocytes/Macrophages",
             "Fibroblasts",
             "Pericytes/SMC",
             "Fibroblasts",
             "Enteric Glial Cells",
             "Enterocyte",
             "Tumor Epithelial Cells",
             "B/Plasma cells",
             "T cells",
             "Epithelial",
             "T cells",
             "B/Plasma cells",
             "Mast cells"
)

afidens=mapvalues(Idents(yjsl), from = levels(Idents(yjsl)), to = ann.ids)
Idents(yjsl)=afidens
yjsl$cellType=Idents(yjsl)

library(Seurat)
library(ggplot2)


genes <- list("B/Plasma cells" = c("IGKC","JCHAIN","MZB1","XBP1"),
              "Monocytes/Macrophages"= c("CD68", "FCGR3A","LST1"),
              "Endothelial" = c("CLDN5", "ENG","FLT1"),
              "Fibroblasts" = c("COL1A1", "DCN","MMP2","ACTA2"),
              "Enterocyte" = c("CA1", "CA2"),
              "Epithelial" = c("CLDN3", "EPCAM","KRT18"),
              "Pericytes/SMC" = c("ACTA2", "MCAM","MYH11"),
              "T cells" = c("CD3D", "CD3E","TRAC","CD8A", "CD8B","GZMB"),
              "Mast"=c("CPA3","KIT"),
              "Enteric Glial Cells"=c("S100B","PLP1"),
              "Tumor Epithelial Cellss"=c("MMP7","CEACAM6")
              
)
# 
features_vec <- unique(unlist(genes))

#DotPlot
dot_plot <- DotPlot(yjsl, features = features_vec, assay = "RNA") +
  scale_color_gradient2(low = "#4A4F7E", mid = "#B8DBB3", high = "#E53528", midpoint = 0) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal(base_size = 8)

# DotPlot
print(dot_plot)


ggsave("dotplot.png", dot_plot, width = 10, height = 8, dpi = 300)

library(Seurat)
library(ggplot2)

genes <- c("BCL2", "ALAD", "MAPK3", "HMOX1", "IL1B", "NLRP3")

# 生成DotPlot
dot_plot <- DotPlot(yjsl, features = genes, assay = "RNA") +
  scale_color_gradient2(low = "#FAA71BFF", mid = "#E55D27FF", high = "#706999FF", midpoint = 0) +   # 设置颜色渐变
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +  # 横坐标基因名旋转
  theme_minimal(base_size = 12)

# DotPlot
print(dot_plot)

# 
ggsave("dotplot_custom_genes.png", dot_plot, width = 10, height = 6, dpi = 300)



#########Visualization of the results after manual annotation
# UMAP/tSNE


DimPlot(yjsl, reduction = "umap", label = T, label.size = 2.5)+theme_classic()+theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),
       legend.position = "right")


DimPlot(yjsl, reduction = "tsne", label = T, label.size = 2.5)+theme_classic()+theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),legend.position = "right")

library(ggsci)
cors <- pal_igv()(12) #

DimPlot(yjsl,reduction = "tsne",label = T,group.by="seurat_clusters",cols = cors)
DimPlot(yjsl,reduction = "umap",label = T,label.size = 2.5,group.by="cellType",cols = cors)
##umap

clusterCornerAxes(object = yjsl, reduction = 'umap',
                  clusterCol = "cellType", #分类依据
                  #noSplit = F, groupFacet = 'cellType', #分组时使用
                  addCircle = F, cicAlpha = 0.03, nbin = 100,  #画圈
                  cellLabel = T,cellLabelSize = 3.5) +  #标签
  scale_color_igv() + scale_fill_igv()


my.color <- c("#AF4034", "#55967e", '#006a8e', "#6a60a9",  
              "#D55E00", "#E39E3E", "#0072B2", 
              "#CC79A7", '#f9a11b', "#4F86C6", "#fdc23e",
              "#e3632d")

p1 <- DimPlot(object = yjsl, cols = my.color, pt.size = 0.5, 
              label = TRUE, reduction = "umap", label.size = 4, repel = TRUE) +
  theme(text = element_text(family = "sans"))
p1

ggsave("DimPlot_umap.pdf", plot = p1, width = 10, height = 8, dpi = 300)




markers_Type <- FindAllMarkers(yjsl, only.pos = F, min.pct = 0.25, logfc.threshold = 0.25)


save(markers_Type,file = "markers_Type.rda")

load("markers_Type.rda")

write.csv(markers_Type,file = "markers.csv")

#top 5
top5markers_Type <- markers_Type %>%
  group_by(cluster) %>%
  top_n(n = 5, wt = avg_log2FC)

#heatmap
DoHeatmap(yjsl, features = top5markers_Type$gene) +
  ggsci::scale_colour_npg() +
  scale_fill_gradient2(low = '#0099CC', mid = 'white', high = '#CC0033', 
                       name = 'Z-score')

#######color##########
colaa=distinctColorPalette(100)

#violin
VlnPlot(yjsl, features = "CD3E",group.by="cellType")+NoLegend()

## umap
FeaturePlot(yjsl,features = "HMOX1")


symbol=c("CD3D",    #
          "CD163",
          "CD79A",
          "FGF7",
          "PECAM1",
          "TPSAB1",
          "CDH1")  

VlnPlot(yjsl, features = symbol,group.by = "cellType", stack=TRUE,cols = colaa)+ NoLegend()   

p<-VlnPlot(yjsl, features = symbol,stack=T,pt.size=0,flip = T,split.by = 'cellType',
           group.by = "cellType",
           cols = c("#78C2C4","#C73E3A"),
           split.plot = T)+
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title = element_blank(),
        axis.text.x = element_text(colour = 'black',size = 10,angle = 90),
        legend.position = 'none')
p

save(yjsl,file = "yjsl_Type.rda")

# =========================
# Save intermediate tables for figure reproducibility
# =========================

# A. UMAP coordinates for annotated cell types
umap_df <- Embeddings(yjsl, "umap") %>% as.data.frame()
umap_df$cell_id <- rownames(umap_df)
umap_df$cellType <- yjsl$cellType
if ("seurat_clusters" %in% colnames(yjsl@meta.data)) {
  umap_df$seurat_clusters <- yjsl@meta.data$seurat_clusters
}
write.csv(umap_df, "umap_coordinates.csv", row.names = FALSE)

# B. DotPlot table for annotation marker genes
features_vec1 <- unique(unlist(genes))
features_vec1 <- features_vec1[features_vec1 %in% rownames(yjsl)]
p_dot1 <- DotPlot(yjsl, features = features_vec1, assay = "RNA")
annotation_dotplot_table <- p_dot1$data
write.csv(annotation_dotplot_table, "annotation_dotplot_table.csv", row.names = FALSE)

# C. DotPlot table for selected genes shown in the manuscript
genes2 <- c("BCL2", "ALAD", "MAPK3", "HMOX1", "IL1B", "NLRP3")
genes2 <- genes2[genes2 %in% rownames(yjsl)]
p_dot2 <- DotPlot(yjsl, features = genes2, assay = "RNA")
selected_gene_dotplot_table <- p_dot2$data
write.csv(selected_gene_dotplot_table, "selected_gene_dotplot_table.csv", row.names = FALSE)

# D. FeaturePlot source data for HMOX1
feature_df <- FetchData(yjsl, vars = c("HMOX1", "cellType"))
feature_df$cell_id <- rownames(feature_df)
umap_embed <- Embeddings(yjsl, "umap") %>% as.data.frame()
featureplot_HMOX1_table <- cbind(
  cell_id = rownames(umap_embed),
  umap_embed,
  feature_df[rownames(umap_embed), , drop = FALSE]
)
write.csv(featureplot_HMOX1_table, "featureplot_HMOX1_table.csv", row.names = FALSE)

