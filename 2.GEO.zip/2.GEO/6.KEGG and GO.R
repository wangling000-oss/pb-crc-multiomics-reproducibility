library(DOSE)
library(clusterProfiler)
library(org.Hs.eg.db)
library(org.Mm.eg.db) 
library(dplyr)
library(GOplot)
library(viridis)
library(DOSE)
library(ggplot2)
library(tidyr)
install.packages("viridis")
library(viridis)


# Set the file path containing the experimental data
file_path <- "genes.txt"

# Read the experimental data table, tab-delimited, with header, and keep original column names
table_data <- read.table(file_path, sep = "\t", header = TRUE, check.names = FALSE)

# Extract the first column of the table, which contains gene names
gene_column <- table_data[[1]]

# Create an empty vector to store Entrez IDs
entrez_ids <- c()

# Loop through each gene in the gene name column
for (gene in gene_column) {
  # Use tryCatch to capture possible errors
  id <- tryCatch({
    # Use mget to map gene symbols to Entrez IDs
    mget(gene, org.Hs.egSYMBOL2EG)
  }, error = function(e) {
    # Return NA if an error occurs
    NA
  })
  
  # Append the matched Entrez ID to the entrez_ids vector
  entrez_ids <- c(entrez_ids, id)
}

# Convert the Entrez ID vector to a character vector
entrez_ids <- as.character(entrez_ids)

# Add the Entrez ID vector to the original table as a new column named entrezID
table_data <- cbind(table_data, entrezID = entrez_ids)

# Remove rows with NA in the Entrez ID column, i.e., genes that could not be mapped
table_data <- table_data[!is.na(table_data[, "entrezID"]), ]

# Extract the Entrez ID column from the table
gene <- table_data$entrezID

# Perform GO enrichment analysis with p-value and q-value cutoffs, using all ontologies and readable gene names
GO <- enrichGO(gene = gene, 
               OrgDb = org.Hs.eg.db, 
               pvalueCutoff = 0.05,# Set p-value cutoff to 0.05 to retain significantly enriched GO terms
               qvalueCutoff = 0.05,# Set q-value cutoff to 0.05 for further filtering of significant GO terms
               ont = "all",
               readable = TRUE)

# Write GO enrichment results to GO.txt, tab-delimited, without row names
write.table(GO, file = "GO.txt", sep = "\t", quote = FALSE, row.names = FALSE)

#### Select pathways of interest for visualization
interest_terms <- c("GO:0009410", "GO:0010038", "GO:0006979", "GO:0050727", 
                    "GO:0071248", "GO:0072593", "GO:0045428", "GO:1904019", 
                    "GO:2001236", 
                    "GO:0045121", "GO:0098857", "GO:0005788", "GO:0031968", 
                    "GO:0019867", "GO:0005769", "GO:0055037", "GO:0005741",  
                    "GO:0005635", 
                    "GO:0005126", "GO:0002020", "GO:0016829","GO:0061134", 
                    "GO:0016504", "GO:0016684", "GO:0004601","GO:0033293", 
                    "GO:0004197")
# Check whether these pathways of interest are present in the GO results
selected_GO <- subset(GO, GO$ID %in% interest_terms)

new_GO <- GO
# Assign the selected_GO content to the result slot of new_GO
new_GO@result <- selected_GO

### Bubble plot
pdf("GO.pdf", width = 13, height = 10)

# Check whether GO results are non-empty
if (length(new_GO) > 0) {
  # Draw a bubble plot showing the top ontology categories, ordered by gene ratio
  dotplot(new_GO, showCategory = 10, split = "ONTOLOGY", orderBy = "GeneRatio") +
    # Create faceted panels for each ontology
    facet_grid(ONTOLOGY ~ ., scale = "free")
} else {
  # Print a message if the data are empty
  cat("Data are empty, unable to generate the dot plot.\n")
}
# Close the PDF device
dev.off()

### Bar plot
pdf("GO.pdf", width = 13, height = 10)
# Check whether GO results are non-empty
if (length(new_GO) > 0) {
  # Draw a bar plot showing the top ontology categories
  barplot(new_GO, drop = TRUE, showCategory = 10, split = "ONTOLOGY") +
    # Create faceted panels for each ontology
    facet_grid(ONTOLOGY ~ ., scale = "free")
} else {
  # Print a message if the data are empty
  cat("Data are empty, unable to generate the bar plot.\n")
}

# Close the PDF device
dev.off()

#### Change plotting style
# Set plot width and height
options(repr.plot.width=9, repr.plot.height=9)

# Define colors
color <- c('lightsteelblue', 'mistyrose3','#6AB4C1') 
cmap <- "cividis" # Directly select the desired color map

# Convert "ONTOLOGY" and "Description" to factors and adjust their level order
selected_GO$ONTOLOGY <- factor(selected_GO$ONTOLOGY, levels=c('BP', 'CC', 'MF'))  
selected_GO$Description <- factor(selected_GO$Description, levels=rev(selected_GO$Description))

# Create the base bar plot
p <- ggplot(data = selected_GO, aes(x = Count, y = Description, fill=ONTOLOGY)) +
  geom_bar(width = 0.5, stat='identity') + # Draw bar plot with width 0.5
  theme_classic() + # Use classic theme
  scale_x_continuous(expand = c(0, 0.5)) + # Adjust x-axis expansion
  scale_fill_manual(values = alpha(color, 0.65)) # Set custom fill colors with transparency

# Add descriptive text labels (remove y-axis text and annotate manually)
p <- p + theme(axis.text.y = element_blank()) +  
  geom_text(aes(x = 0.1, y = Description, label = Description), # Add descriptions next to bars
            size = 4.5, hjust = 0) 

# Add gene ID and p-value information
p <- p + geom_text(aes(x = 0.1, y = Description, label = ID, color = -log10(pvalue)), 
                   size = 3, fontface = 'italic', hjust = 0, vjust = 2.7) +  
  scale_colour_viridis(option = cmap, direction = 1) # Map p-values using the Viridis color scale
p
# Save the plot as a PDF file
ggsave("GO2.pdf", p, width=9, height=7) 
dev.off()
dev.off()




##################### KEGG enrichment analysis ########################
##################### KEGG enrichment analysis ########################
##################### KEGG enrichment analysis ########################
##################### KEGG enrichment analysis ########################


# Perform KEGG enrichment analysis with input gene list, organism name, and p/q cutoffs
KEGG <- enrichKEGG(gene = gene,
                   organism = "hsa",
                   pvalueCutoff = 1,
                   qvalueCutoff = 1)


# Convert KEGG enrichment results to a data frame

KEGGG <- as.data.frame(KEGG)
KEGGG <- KEGGG[, !names(KEGGG) %in% "category"]

# Rename the subcategory column to ONTOLOGY
names(KEGGG)[names(KEGGG) == "subcategory"] <- "ONTOLOGY"

# Set all values in the ONTOLOGY column to KEGG
KEGGG$ONTOLOGY <- "KEGG"
KEGG2 <- KEGG
KEGG2@result <- KEGGG
write.table(KEGG, file = "KEGG.txt", sep = "\t", quote = FALSE, row.names = FALSE)
interest_terms2 <- c("hsa04657", "hsa04668","hsa04621","hsa05208",
                     "hsa05204", "hsa04064", "hsa04620","hsa04010","hsa04151")

# Check whether these pathways of interest are present in the GO results
selected_GO2 <- subset(KEGG2, KEGG2$ID %in% interest_terms2)

# Assign the selected_GO content to the result slot of new_GO
KEGG2@result <- selected_GO2

### Bubble plot
pdf("KEGG.pdf", width = 13, height = 10)

# Check whether GO results are non-empty
if (length(KEGG2) > 0) {
  # Draw a bubble plot showing the top ontology categories, ordered by gene ratio
  dotplot(KEGG2, showCategory = 10, split = "ONTOLOGY", orderBy = "GeneRatio") +
    # Create faceted panels for each ontology
    facet_grid(ONTOLOGY ~ ., scale = "free")
} else {
  # Print a message if the data are empty
  cat("Data are empty, unable to generate the dot plot.\n")
}
# Close the PDF device
dev.off()

### Bar plot
pdf("KEGG.pdf", width = 13, height = 10)
# Check whether GO results are non-empty
if (length(KEGG2) > 0) {
  # Draw a bar plot showing the top ontology categories
  barplot(KEGG2, drop = TRUE, showCategory = 5, split = "ONTOLOGY") +
    # Create faceted panels for each ontology
    facet_grid(ONTOLOGY ~ ., scale = "free")
} else {
  # Print a message if the data are empty
  cat("Data are empty, unable to generate the bar plot.\n")
}

# Close the PDF device
dev.off()
#########
# Plot KEGG results
options(repr.plot.width=8, repr.plot.height=8)  

# Define colors and colormap
color <- c('pink')
cmap <- c("viridis", "magma", "inferno", "plasma", "cividis", "rocket", "mako", "turbo")

# Ensure ONTOLOGY and Description are factors with the desired order
selected_GO2$ONTOLOGY <- factor(selected_GO2$ONTOLOGY, levels = c('KEGG'))
selected_GO2$Description <- factor(selected_GO2$Description, levels = rev(selected_GO2$Description))

# Create the initial plot
p <- ggplot(data = selected_GO2, aes(x = Count, y = Description, fill = ONTOLOGY)) +
  geom_bar(width = 0.5, stat = 'identity') +  # Bar plot
  theme_classic() +  # Classic theme
  scale_x_continuous(expand = c(0, 0.5)) +  # Adjust X-axis expansion
  scale_fill_manual(values = alpha(color, 0.65))  # Set custom fill color with transparency

# Add KEGG term labels
p <- p + theme(axis.text.y = element_blank()) +  # Remove Y-axis text for readability
  geom_text(aes(x = 0.1, y = Description, label = Description), size = 4.5, hjust = 0)  # Add Description labels

# Add ID and p-value labels
p <- p + geom_text(aes(x = 0.1, y = Description, label = ID, color = -log10(pvalue)), 
                   size = 3, fontface = 'italic', hjust = 0, vjust = 2.7) +  # Add ID labels and color by p-value
  scale_colour_viridis(option = cmap[5], direction = 1)  # Use cividis color scale for p-values
p
# Save the plot as a PDF file
ggsave("KEGG_Enrichment_Analysis.pdf", p, width = 8, height = 4)

# Close any open graphics devices
dev.off()
dev.off()




############ Plot GO and KEGG together
############ Plot GO and KEGG together
############ Plot GO and KEGG together
# Combine the two data frames row-wise
selected_GO3 <- rbind(selected_GO, selected_GO2)


### Plotting
options(repr.plot.width=9, repr.plot.height=9) 
# Customize colors and colormap options
color <- c('lightsteelblue', 'mistyrose3','#6AB4C1',"pink") 
cmap <- c("viridis", "magma", "inferno", "plasma", "cividis", "rocket", "mako", "turbo")  

# Set factor levels to control the display order in the plot
selected_GO3$ONTOLOGY <- factor(selected_GO3$ONTOLOGY, levels=c('BP', 'CC','MF',"KEGG")) 
selected_GO3$Description <- factor(selected_GO3$Description, levels = rev(selected_GO3$Description))

# Draw the bar plot
p <- ggplot(selected_GO3, aes(x = Count, y = Description, fill = ONTOLOGY)) +
  geom_bar(width = 0.5, stat = 'identity') +  # Use bars to represent the count of each category
  theme_classic() +  # Use classic theme style
  scale_x_continuous(expand = c(0, 0.5)) +  # Set x-axis appearance
  scale_fill_manual(values = alpha(color, 0.65))  # Set fill colors and transparency

# Hide y-axis labels and manually add text labels
p <- p + theme(axis.text.y = element_blank()) + 
  geom_text(aes(x = 0.1, y = Description, label = Description), size = 3, hjust = 0)

# Add ID labels and adjust color intensity using -log10(pvalue)
p <- p + geom_text(aes(x = 0.1, y = Description, label = ID, color = -log10(pvalue)), 
                   size = 2, fontface = 'italic', hjust = 0, vjust = 2.5) +
  scale_colour_viridis(option = cmap[5], direction = 1)  # Use viridis colormap
p
# Save the plot to a PDF file
ggsave("GOKEGG.pdf", p, width = 7, height = 10) 
dev.off()
dev.off()