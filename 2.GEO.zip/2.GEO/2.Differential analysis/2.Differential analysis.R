# if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
# BiocManager::install("limma")
# install.packages("pheatmap")

install.packages("BiocManager")
BiocManager::install("limma")

library(limma)
library(pheatmap)

inputFile="0930merge.txt"       
logFCfilter=0               
adj.P.Val.Filter=0.05       

rt=read.table(inputFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
data=data[rowMeans(data)>0,]

#Read the "notes.txt" file to obtain the sample names and group information
notesFile="0930notes.txt"
notesData=read.table(notesFile, header=T, sep="\t", check.names=F)
colnames(notesData)[1] <- "sampleName"  

# control vs treatment
sampleName1=as.vector(notesData[notesData$group=="control", "sampleName"])
sampleName2=as.vector(notesData[notesData$group=="treat", "sampleName"])

# Extract the data of the control group and the treatment group
conData=data[,sampleName1]
treatData=data[,sampleName2]
data=cbind(conData,treatData)
conNum=ncol(conData)
treatNum=ncol(treatData)

# differential analysis
Type=c(rep("con",conNum),rep("treat",treatNum))
design <- model.matrix(~0+factor(Type))
colnames(design) <- c("con","treat")
fit <- lmFit(data,design)
cont.matrix<-makeContrasts(treat-con,levels=design)
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)

allDiff=topTable(fit2,adjust='fdr',number=200000)
allDiffOut=rbind(id=colnames(allDiff),allDiff)
write.table(allDiffOut, file="DE.txt", sep="\t", quote=F, col.names=F)

# Output the corrected expression quantity
outData=rbind(id=paste0(colnames(data),"_",Type),data)
write.table(outData, file="DE_exp.txt", sep="\t", quote=F, col.names=F)

# Output the difference results
diffSig=allDiff[with(allDiff, (abs(logFC)>logFCfilter & adj.P.Val < adj.P.Val.Filter )), ]
diffSigOut=rbind(id=colnames(diffSig),diffSig)
write.table(diffSigOut, file="DEGS.txt", sep="\t", quote=F, col.names=F)

# Output the expression levels of differentially expressed genes
diffGeneExp=data[row.names(diffSig),]
diffGeneExpOut=rbind(id=paste0(colnames(diffGeneExp),"_",Type), diffGeneExp)
write.table(diffGeneExpOut, file="DEGS_exp.txt", sep="\t", quote=F, col.names=F)

