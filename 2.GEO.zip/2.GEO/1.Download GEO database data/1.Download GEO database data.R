
library(GEOquery)    
library(stringr)     
library(limma)       
library(tidyverse)   

# The getGEO function downloads the dataset with the specified ID from the GEO database.
gset <- getGEO("GSE74602", destdir=".", AnnotGPL = F, getGPL = F)  

# Extract the first expression matrix of the downloaded dataset
a <- gset[[1]] 
# Obtain the expression matrix
dat <- exprs(a)  

# Examine the dimensions of the data matrix (the number of rows and columns), that is, the number of genes and the number of samples
dim(dat)  
# Output the first four rows and four columns of the expression matrix to assist in checking the data format.
dat[1:4, 1:4]  


# Manually download platform data
ids= read.table('.txt', sep = "\t", header = T) 

# Check the data format
ids[1:5,] 

# Extract the first gene before "///" in the Gene.Symbol column
{
ids$Gene.Symbol <- sapply(strsplit(as.character(ids$Gene.Symbol), " /// "), `[`, 1)
}

head(ids, 5)  

{
# Rename the column names of the annotation data frame to "probe_id" (probe ID) and "symbol" (gene symbol)
colnames(ids) <- c("probe_id", "symbol")

# Check the data in the previous few rows
head(ids)  
}

# Match the probe ID with the column names of the expression matrix
ids <- ids[match(rownames(dat), ids$probe_id), ]  

# Delete duplicate gene symbols. If multiple probes map to the same gene, retain only one gene symbol.
ids <- ids[!duplicated(ids$symbol), ]  


# Reorder the rows of the expression matrix so that they match the order of probe IDs in the ids array.
dat <- dat[ids$probe_id, ] 
rownames(dat) <- ids$symbol  

dat <- as.data.frame(dat)  
dat = na.omit(dat) 
dat = dat[rowMeans(dat) > 1,]
dat = log2(dat + 1)  

# data correction ------------------------------
boxplot(dat, outline=FALSE, notch=F, las=2)


dat = normalizeBetweenArrays(dat)

boxplot(dat, outline=FALSE, notch=F, las=2)

# save
write.table(dat, file = "GSE74602.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)
