library(correlation) 
library(ggplot2)
library(ggpubr)
library(ggpointdensity) 
library(viridis)
library(corrplot) 
#remotes::install_github('r-link/corrmorant')
library(corrmorant) 
library(cols4all)

dt <- read.csv(".csv",row.names = 1)


#Pairwise correlation
cor3 <- cor(dt)
cor3[1:6,1:5]

#Significance calculation
res <- cor.mtest(dt, conf.level = .95)
p <- res$p
#Obtain the matrix of significance values
p[1:6,1:5] 

#draw：
corrplot(cor3)
#Different correlation heatmap styles:
# Optional graphic styles："circle", "square", "ellipse", "number", "shade", "color", "pie"
corrplot(cor3, method = c('square'))
corrplot(cor3, method = c('ellipse'))
corrplot(cor3, method = c('number'))
corrplot(cor3, method = c('shade'))
corrplot(cor3, method = c('color'))
corrplot(cor3, method = c('pie'))

#color：
mycol <- colorRampPalette(c("#06a7cd", "white", "#e74a32"), alpha = TRUE)

#upper：
##significant
corrplot(
  cor3,
  method = c('pie'), type = c('upper'), col = mycol(100),
  outline = 'grey', order = c('AOE'), diag = TRUE,
  tl.cex = 1, tl.col = 'black', tl.pos = 'd',
  p.mat = p,
  sig.level = c(.001, .01, .05),
  insig = "label_sig", #"pch", "p-value", "blank", "n", "label_sig"
  pch.cex = 1.2, #
  pch.col = 'black' #color
)


#Lower graph (lower triangle) overlay:
## Cross out insignificant values + display the numbers
corrplot(
  cor3,
  add = TRUE,
  method = c('number'), type = c('lower'), col = mycol(100),
  order = c('AOE'), diag = FALSE, number.cex = 0.9,
  tl.pos = 'n', cl.pos = 'n',
  p.mat = p,
  insig = "pch"
)

