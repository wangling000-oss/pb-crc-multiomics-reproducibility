# install.packages("ggplot2")
# install.packages("ggrepel")


library(dplyr)
library(ggplot2)
library(ggrepel)

filter_logFC <- 0
filter_adjPVal <- 0.05     
data_file ="DE.txt"         

# Read the data file
data_table <- read.table(data_file, header = TRUE, sep = "\t", check.names = FALSE)

# The logical conditions for defining the significance of genes
significance <- ifelse((data_table$adj.P.Val < filter_adjPVal) & (abs(data_table$logFC) > filter_logFC),
                       ifelse(data_table$logFC > filter_logFC, "Up", "Down"), "Not")

# Add significance column to the data table
data_table <- mutate(data_table, Sig = significance)

# volcano map
plot <- ggplot(data_table, aes(x = logFC, y = -log10(adj.P.Val))) +
  geom_point(aes(color = Sig)) +
  scale_color_manual(values = c("green", "black", "red")) +
  labs(title = "") +
  theme(plot.title = element_text(size = 16, hjust = 0.5, face = "bold"))

# Add labels to the genes with significant differences
plot_with_labels <- plot +
  geom_label_repel(data = subset(data_table, (adj.P.Val < filter_adjPVal) & (abs(logFC) > filter_logFC)),
                   box.padding = 0.1, point.padding = 0.1, min.segment.length = 0.05,
                   size = 1.8, aes(label = id)) +
  theme_bw()

# PDF
pdf("vol.pdf", width = 7, height = 6.1)
print(plot_with_labels)
dev.off()