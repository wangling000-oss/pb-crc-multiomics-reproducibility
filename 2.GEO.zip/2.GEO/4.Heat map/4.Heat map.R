
library(pheatmap) # install.packages("pheatmap")


# data loading
df<-read.table("DEGS_exp.txt",header = TRUE,row.names = 1)

# data standardization
df_scale<-as.data.frame(scale(df))

# The purpose of grouping is to display the blocks of the groups.
type<-data.frame(row.names = colnames(df),type=colnames(df))
type$type<-sub("[^comtreat]+","",type$type) # 
type[type$type=="con",]<-"control" # 
df_scale<-df_scale[1:50,]
# draw
pheatmap(df_scale, # 
         cluster_cols = FALSE, 
         show_colnames = FALSE, # 
         fontsize = 8, 
         fontsize_row = 5, 
         annotation_col = type, #
         filename = "plot.pdf",
         width = 8.88, # width
         height = 10) # high
