# Legacy visualization only; used for candidate-gene identification and illustrative figures.
# Not used for the primary reproducible performance evaluation.
# For candidate-gene identification / visualization only; not the primary reproducible validation pipeline.

#Set the working directory


library(randomForest)
library(limma)
library(ggpubr)
set.seed(123)

##Read the gene expression matrix file from the specified path and set the first column as the row names.
data <-read.csv("1001Correlation.csv",row.names = 1)
#Read target gene
genelist<-read.csv("1001classified information.csv",row.names = 1)

#Convert the `type` column in the classification information into a character vector, which will be used as the grouping label for the samples.
group <- as.character(genelist$type)


#RF
# Use the random forest algorithm to build the model, with the response variable being `group` and the independent variables being all the gene expression data in `data`.
#ntree=500 Specifies the construction of 500 trees
rf=randomForest(as.factor(group)~., data=data, ntree=500, importance=TRUE)
#?randomForest
pdf(file="PDF1.pdf", width=6, height=6)
plot(rf, main="Random forest", lwd=2)
dev.off()


#In the random forest model, determine the number of trees with the lowest classification error rate
# `which.min` returns the number of trees corresponding to the row with the lowest error rate
optionTrees=which.min(rf$err.rate[,1])
# The number of trees with the smallest output error, which is used for subsequent optimization of the model
optionTrees
# Rebuild the random forest model, using the optimal number of trees `optionTrees` that was determined earlier.
rf2=randomForest(as.factor(group)~., data=data, ntree=optionTrees, importance=TRUE)
plot(rf2, main="Random forest", lwd=2)

# Extract the importance of genes
imp <- importance(rf2)
imp <- as.data.frame(imp)
imp$Gene <- rownames(imp)

# View the "Importance" column of the options
print(colnames(imp))

#  MeanDecreaseGini
importance_df <- imp[, c("Gene", "MeanDecreaseGini")]
colnames(importance_df) <- c("Gene", "importance")

# Display the first 15 genes
af <- importance_df[order(importance_df$importance, decreasing = TRUE), ]
af <- af[1:15, ]

# 
p1 <- ggplot(af, aes(x = reorder(Gene, importance), y = importance, fill = importance)) +  
  geom_bar(stat = "identity", width = 0.7) +  
  coord_flip() +  
  scale_fill_gradient(low = ggsci::pal_npg()(2)[1], high = ggsci::pal_npg()(2)[2]) +  
  labs(x = "Gene", y = "Importance", title = "Top 15 Genes by Importance") +  
  theme_bw() +  
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1), 
    axis.text.y = element_text(size = 12),
    plot.title = element_text(hjust = 0.5),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

print(p1)

pdf(file = "1.pdf", width = 6, height = 6)
print(p1)
dev.off()

# 
p2 <- ggdotchart(
  af, x = "Gene", y = "importance",
  color = "importance",
  sorting = "descending",
  add = "segments",
  add.params = list(color = "lightgray", size = 2),
  dot.size = 6,
  font.label = list(color = "white", size = 9, vjust = 0.5),
  ggtheme = theme_bw(),
  rotate = TRUE
)

p3 <- p2 +
  geom_hline(yintercept = 0, linetype = 2, color = "lightgray") +
  gradient_color(palette = c(ggsci::pal_npg()(2)[2], ggsci::pal_npg()(2)[1]))

print(p3)

pdf(file = "2.pdf", width = 6, height = 6)
print(p3)
dev.off()

# 
rfGenes <- importance_df[order(importance_df$importance, decreasing = TRUE), ]
write.csv(rfGenes, "3.csv", row.names = FALSE)
