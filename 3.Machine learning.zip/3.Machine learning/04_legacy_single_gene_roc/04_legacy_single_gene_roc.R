# Legacy visualization only; used for candidate-gene identification and illustrative figures.
# Not used for the primary reproducible performance evaluation.
# For candidate-gene identification / visualization only; not the primary reproducible validation pipeline.
#设置工作目录
setwd("XXX") 

library(pROC)

# Read the data file
your_data = read.table("AUC.txt", header=TRUE, sep="\t", check.names=FALSE, row.names=1)

# Determine the column name of the dependent variable (the outcome variable)
y = colnames(your_data)[1]

# Obtain the names of all the genes that need to be used for drawing the ROC curve
genes = colnames(your_data)[-1]  # 排除结果变量列

# Set the output PDF file
image_result = "ROC.pdf"


pdf(file=image_result, width=6, height=6)

# Initialize graphic parameters
plot(NULL, xlim=c(1, 0), ylim=c(0, 1), xlab="Specificity", ylab="Sensitivity", main="ROC Curves", type="n")

# Draw a dotted line from the lower left to the upper right.
abline(a=0, b=-1, col="gray", lty=2)

# Define the color list and ensure that the quantity is consistent with the number of genes.
colors <- rainbow(length(genes))
#
colors <- c("#8C6BB1", "#A6BDDB", "#FB9A99","#7FC97F","#FEE391","#ED8D51")
# Initialize a list to store the AUC values
auc_list <- list()

# Use a loop to draw the ROC curve for each gene
for (i in seq_along(genes)) {
  gene <- genes[i]
  roc_result = roc(your_data[, y], as.vector(your_data[, gene]))
  plot(roc_result, col=colors[i], add=TRUE)
  auc_list[[gene]] <- auc(roc_result)  # 存储AUC值
}

# add legend
legend("bottomright", legend=paste(names(auc_list), ": AUC =", round(unlist(auc_list), 3)), 
       col=colors, lwd=2, cex=0.8)

# turn off
dev.off()


##### Draw separately
# Use a loop to draw a separate ROC curve for each gene
for (i in seq_along(genes)) {
  gene <- genes[i]
  
  pdf(file=paste0(gene, "_ROC.pdf"), width=6, height=6)
  plot(NULL, xlim=c(1, 0), ylim=c(0, 1), xlab="Specificity", ylab="Sensitivity", main=paste("ROC Curve for", gene), type="n")
  abline(a=0, b=-1, col="gray", lty=2)
  roc_result = roc(your_data[, y], as.vector(your_data[, gene]))
  plot(roc_result, col=colors[i], add=TRUE)
  auc_value <- auc(roc_result)

  legend("bottomright", legend=paste(gene, ": AUC =", round(auc_value, 3)), 
         col=colors[i], lwd=2, cex=0.8)
  
  dev.off()
}

####another


# 
for (i in seq_along(genes)) {
  gene <- genes[i]
  pdf(file=paste0(gene, "_ROC2.pdf"), width=6, height=6)
  plot(NULL, xlim=c(1, 0), ylim=c(0, 1), xlab="Specificity", ylab="Sensitivity", main=paste("ROC Curve for", gene), type="n")
  # Draw a dotted line from the lower left to the upper right.
  # abline(a=0, b=-1, col="gray", lty=2)
  roc_result = roc(your_data[, y], as.vector(your_data[, gene]))
  polygon(c(1, roc_result$specificities, 0), c(0, roc_result$sensitivities, 0), col=adjustcolor(colors[i], alpha.f=0.3), border=NA)
  polygon(c(1, 0, 0, 1), c(0, 1, 0, 0), col=adjustcolor(colors[i], alpha.f=0.3), border=NA)
  lines(roc_result$specificities, roc_result$sensitivities, col=colors[i], lwd=2)
  auc_value <- auc(roc_result)
  legend("bottomright", legend=paste(gene, ": AUC =", round(auc_value, 3)), col=colors[i], lwd=2, cex=0.8)
  dev.off()
}
