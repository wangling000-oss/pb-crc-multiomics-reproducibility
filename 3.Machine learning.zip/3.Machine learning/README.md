# Machine-learning reproducibility

This reproducibility package contains the materials for the revised machine-learning analysis.

## 1. Main reproducible pipeline

The primary reproducible machine-learning workflow is provided in the folder `01_main_reproducible_pipeline/`, which contains the following scripts:

- `01_make_splits.R`
- `02_run_nested_svm_rfe.R`
- `03_make_roc_from_outer_predictions.R`
- `04_fit_final_nomogram.R`
- `run_all_pipeline.R`

The main performance estimate reported in the revised manuscript is based on the nested cross-validation workflow implemented in this folder.

In the revised workflow, feature selection, hyperparameter tuning, and model fitting are all performed strictly within the training data of each resampling split. The held-out test fold is used only for final evaluation. This design was used to avoid information leakage and to ensure methodological reproducibility.

## 2. Legacy visualization scripts

The folders `02_legacy_rf_importance/`, `03_legacy_svm_screening/`, `04_legacy_single_gene_roc/`, and `05_legacy_nomogram_visualization/` contain legacy scripts used for candidate-gene identification and illustrative visualization in the original manuscript preparation.

These scripts are retained for transparency and archival reference, but they are not used for the primary unbiased estimate of predictive performance in the revised manuscript. Each of these folders also contains the corresponding input files required to reproduce the associated legacy visualization results.

## 3. Output files

The main reproducible outputs include:

### Core nested cross-validation outputs
- `split_summary.csv`
- `outer_fold_predictions.csv`
- `selected_features_by_fold.csv`
- `performance_summary.csv`
- `performance_summary_overall.csv`
- `roc_points_nested_cv.csv`
- `auc_nested_cv.csv`
- `roc_curve_nested_cv.pdf`

These files provide the reproducible split summary, fold-level predictions, selected features, summary performance metrics, ROC point data, AUC summary, and the final nested cross-validation ROC curve reported in the revised manuscript.

### Final model presentation outputs
- `final_nomogram_feature_frequency.csv`
- `final_nomogram_coefficients.csv`
- `final_nomogram.pdf`
- `final_calibration_plot.pdf`
- `final_dca_plot.pdf`

These files provide the feature stability summary across folds, the final model coefficients, and the nomogram-related presentation outputs generated from the final model.
## 4. Recommended execution order

To reproduce the main machine-learning analysis, run the scripts in the following order:

1. `01_make_splits.R`
2. `02_run_nested_svm_rfe.R`
3. `03_make_roc_from_outer_predictions.R`
4. `04_fit_final_nomogram.R`

Alternatively, the entire main pipeline can be executed using `run_all_pipeline.R`.

## 5. Reproducible split indices

The file `reproducible_splits.rds` contains the fixed outer-fold split indices used in the reproducible machine-learning pipeline. This file corresponds to Supplementary 3.

The script `02_run_nested_svm_rfe.R` explicitly loads this file and uses these exact split indices for all outer-fold model training and evaluation, so that identical results can be reproduced under the same predefined splits.

## 6. Canonical machine-learning input files

The files `ml_input_matrix.csv` and `ml_labels.csv` are included in the reproducibility package as the required canonical input files for the machine-learning analysis. All reproducible machine-learning scripts start from these files.

Thus, although the full upstream GEO-to-matrix preprocessing pipeline is not re-executed within the machine-learning workflow, the exact final input matrix used for the reported machine-learning analyses is directly provided in the package. This avoids ambiguity in reconstructing the machine-learning input from earlier GEO-processing steps.