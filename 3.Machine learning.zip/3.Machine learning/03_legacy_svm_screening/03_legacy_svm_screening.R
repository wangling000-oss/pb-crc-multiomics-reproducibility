# Legacy visualization only; used for candidate-gene identification and illustrative figures.
# Not used for the primary reproducible performance evaluation.
# For candidate-gene identification / visualization only; not the primary reproducible validation pipeline.

setwd("XXX")  

##
library(tidyverse)
library(glmnet)
source('msvmRFE.R')   
library(VennDiagram)
library(sigFeature)
library(e1071)
library(caret)
library(randomForest)
set.seed(123)


##Read the file
input <- read.csv("1001classified information.csv",row.names = 1)

##Now let's proceed to the formal analysis.
### Using five-fold cross-validation
svmRFE(input, k = 5, halve.above = 100)

nfold = 5
nrows = nrow(input)
folds = rep(1:nfold, len=nrows)[sample(nrows)]
folds = lapply(1:nfold, function(x) which(folds == x))
results = lapply(folds, svmRFE.wrap, input, k=10, halve.above=200)

# #View the main variables
top.features = WriteFeatures(results, input, save=F)
head(top.features)

#Save the features found by SVM-REF to a file
write.csv(top.features,"feature_svm.csv")



featsweep = lapply(1:15, FeatSweep.wrap, results, input) 
save(featsweep,file = "result.RData")
load("result.RData")
#draw
no.info = min(prop.table(table(input[,1])))
errors = sapply(featsweep, function(x) ifelse(is.null(x), NA, x$error))

#Draw the error rate graph
PlotErrors(errors, no.info=no.info) 

#Draw the accuracy graph  
Plotaccuracy(1-errors,no.info=no.info) 



# The location marked by the red circle in the picture, which is the point with the lowest error rate
which.min(errors)

##
top<-top.features[1:which.min(errors), "FeatureName"]

write.csv(top,"1.csv")



