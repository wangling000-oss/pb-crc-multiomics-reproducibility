# ============================================================
# Script: 03_make_roc_from_outer_predictions.R
# Purpose:
#   Generate ROC curve and AUC using held-out outer-fold predictions
#   from nested cross-validation.
#
# Input:
#   outputs/outer_fold_predictions.csv
#
# Output:
#   outputs/roc_curve_nested_cv.pdf
#   outputs/roc_points_nested_cv.csv
#   outputs/auc_nested_cv.csv
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(tidyverse)
  library(pROC)
})

# ----------------------------
# 1. Paths
# ----------------------------
pred_file <- "outputs/outer_fold_predictions.csv"
roc_pdf   <- "outputs/roc_curve_nested_cv.pdf"
roc_csv   <- "outputs/roc_points_nested_cv.csv"
auc_csv   <- "outputs/auc_nested_cv.csv"

# ----------------------------
# 2. Read predictions
# ----------------------------
pred <- read.csv(pred_file, stringsAsFactors = FALSE)

# expected columns:
# fold_id, sample_id, observed, predicted_class, predicted_prob

stopifnot(all(c("fold_id", "sample_id", "observed", "predicted_prob") %in% names(pred)))

pred$observed <- factor(pred$observed, levels = c("control", "case"))

# ----------------------------
# 3. ROC and AUC
# ----------------------------
roc_obj <- roc(
  response = pred$observed,
  predictor = pred$predicted_prob,
  levels = c("control", "case"),
  direction = "<",
  quiet = TRUE
)

auc_val <- as.numeric(auc(roc_obj))
auc_ci  <- ci.auc(roc_obj)

cat("Nested CV AUC =", round(auc_val, 4), "\n")
cat("95% CI =", round(auc_ci[1], 4), "-", round(auc_ci[3], 4), "\n")

# ----------------------------
# 4. Export ROC points
# ----------------------------
roc_df <- tibble(
  specificity = roc_obj$specificities,
  sensitivity = roc_obj$sensitivities,
  threshold   = roc_obj$thresholds
) %>%
  mutate(fpr = 1 - specificity)

write.csv(roc_df, roc_csv, row.names = FALSE)

auc_df <- tibble(
  AUC = auc_val,
  AUC_CI_lower = as.numeric(auc_ci[1]),
  AUC_CI_upper = as.numeric(auc_ci[3]),
  n_samples = nrow(pred)
)

write.csv(auc_df, auc_csv, row.names = FALSE)

# ----------------------------
# 5. Plot ROC
# ----------------------------
pdf(roc_pdf, width = 6, height = 6)

plot(
  roc_obj,
  legacy.axes = TRUE,
  main = "ROC Curve from Held-out Outer-fold Predictions",
  lwd = 2
)
abline(a = 0, b = 1, lty = 2)

legend(
  "bottomright",
  legend = paste0(
    "AUC = ", sprintf("%.3f", auc_val),
    " (95% CI ", sprintf("%.3f", auc_ci[1]), "-",
    sprintf("%.3f", auc_ci[3]), ")"
  ),
  bty = "n"
)

dev.off()

cat("Saved ROC plot to:", roc_pdf, "\n")
cat("Saved ROC points to:", roc_csv, "\n")
cat("Saved AUC summary to:", auc_csv, "\n")