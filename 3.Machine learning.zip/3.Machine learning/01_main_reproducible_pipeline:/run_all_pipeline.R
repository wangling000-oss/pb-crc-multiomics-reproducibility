rm(list = ls())

script_dir <- getwd()

scripts <- file.path(script_dir, c(
  "01_make_splits.R",
  "02_run_nested_svm_rfe.R",
  "03_make_roc_from_outer_predictions.R",
  "04_fit_final_nomogram.R"
))

for (s in scripts) {
  if (!file.exists(s)) {
    stop("Missing script: ", s)
  }
  cat("Running:", basename(s), "\n")
  source(s, echo = TRUE)
}

cat("Main machine-learning pipeline completed successfully.\n")