# ============================================================
# Script: 02_run_nested_svm_rfe.R
# Purpose:
#   Run nested cross-validation SVM-RFE using:
#   - canonical ML input matrix
#   - canonical label file
#   - fixed outer splits
#
# Reproducibility principles:
#   1) fixed outer splits are explicitly loaded
#   2) scaling is fit on outer training data only
#   3) feature selection is performed on outer training data only
#   4) final evaluation is performed on held-out outer test folds only
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(tidyverse)
  library(caret)
  library(e1071)
  library(pROC)
})

set.seed(20260315)

# ----------------------------
# 1. Paths
# ----------------------------
expr_file  <- "inputs/ml_input_matrix.csv"
label_file <- "inputs/ml_labels.csv"
split_file <- "inputs/reproducible_splits.rds"

pred_file  <- "outputs/outer_fold_predictions.csv"
feat_file  <- "outputs/selected_features_by_fold.csv"
perf_file  <- "outputs/performance_summary.csv"
perf_overall_file <- "outputs/performance_summary_overall.csv"

dir.create("outputs", showWarnings = FALSE, recursive = TRUE)

# ----------------------------
# 2. Read and merge data
# ----------------------------
expr <- read.csv(expr_file, check.names = FALSE, stringsAsFactors = FALSE)
lab  <- read.csv(label_file, check.names = FALSE, stringsAsFactors = FALSE)
split_obj <- readRDS(split_file)

names(expr)[1] <- "sample_id"
names(lab)[1]  <- "sample_id"
names(lab)[2]  <- "label"

dat <- merge(expr, lab, by = "sample_id")
dat$label <- factor(dat$label, levels = c(0, 1), labels = c("control", "case"))

outer_splits <- split_obj$outer_splits

sample_id_col <- "sample_id"
label_col <- "label"
feature_cols <- setdiff(names(dat), c(sample_id_col, label_col))
positive_class <- "case"

# ----------------------------
# 3. Helper functions
# ----------------------------
scale_by_train <- function(x_train, x_test) {
  train_means <- apply(x_train, 2, mean, na.rm = TRUE)
  train_sds   <- apply(x_train, 2, sd, na.rm = TRUE)
  train_sds[train_sds == 0] <- 1
  
  x_train_scaled <- scale(x_train, center = train_means, scale = train_sds)
  x_test_scaled  <- scale(x_test, center = train_means, scale = train_sds)
  
  list(
    x_train = as.data.frame(x_train_scaled),
    x_test  = as.data.frame(x_test_scaled)
  )
}

run_inner_rfe <- function(x_train, y_train, sizes = c(2, 3, 5, 8, 10, 15, 20), seed = 123) {
  set.seed(seed)
  
  ctrl <- rfeControl(
    functions = caretFuncs,
    method = "cv",
    number = 5,
    verbose = FALSE,
    returnResamp = "final"
  )
  
  fit <- rfe(
    x = x_train,
    y = y_train,
    sizes = sizes[sizes <= ncol(x_train)],
    rfeControl = ctrl,
    method = "svmRadial",
    trControl = trainControl(
      method = "cv",
      number = 5,
      classProbs = TRUE,
      summaryFunction = twoClassSummary
    ),
    metric = "ROC"
  )
  
  list(
    selected_features = predictors(fit),
    rfe_fit = fit
  )
}

train_final_svm_on_outer_train <- function(x_train, y_train, seed = 123) {
  set.seed(seed)
  
  ctrl <- trainControl(
    method = "cv",
    number = 5,
    classProbs = TRUE,
    summaryFunction = twoClassSummary,
    savePredictions = "final"
  )
  
  fit <- train(
    x = x_train,
    y = y_train,
    method = "svmRadial",
    metric = "ROC",
    trControl = ctrl,
    tuneLength = 10
  )
  
  fit
}

calc_binary_metrics <- function(obs, prob, positive_class = "case") {
  obs <- factor(obs, levels = c("control", "case"))
  
  roc_obj <- roc(
    response = obs,
    predictor = prob,
    levels = c("control", "case"),
    direction = "<",
    quiet = TRUE
  )
  
  auc_val <- as.numeric(auc(roc_obj))
  
  pred_class <- ifelse(prob >= 0.5, positive_class, "control")
  pred_class <- factor(pred_class, levels = c("control", "case"))
  
  cm <- confusionMatrix(pred_class, obs, positive = positive_class)
  
  tibble(
    AUC = auc_val,
    Accuracy = unname(cm$overall["Accuracy"]),
    Sensitivity = unname(cm$byClass["Sensitivity"]),
    Specificity = unname(cm$byClass["Specificity"])
  )
}

# ----------------------------
# 4. Outer loop
# ----------------------------
all_predictions <- list()
all_features <- list()
all_performance <- list()

for (fold_obj in outer_splits) {
  fold_id <- fold_obj$fold_id
  cat("Running outer fold:", fold_id, "\n")
  
  outer_train_idx <- fold_obj$train_index
  outer_test_idx  <- fold_obj$test_index
  
  train_dat <- dat[outer_train_idx, , drop = FALSE]
  test_dat  <- dat[outer_test_idx, , drop = FALSE]
  
  x_train_raw <- train_dat[, feature_cols, drop = FALSE]
  y_train <- train_dat[[label_col]]
  
  x_test_raw <- test_dat[, feature_cols, drop = FALSE]
  y_test <- test_dat[[label_col]]
  
  # scaling using outer train only
  scaled <- scale_by_train(x_train_raw, x_test_raw)
  x_train_scaled <- scaled$x_train
  x_test_scaled  <- scaled$x_test
  
  # feature selection within outer training data only
  rfe_res <- run_inner_rfe(
    x_train = x_train_scaled,
    y_train = y_train,
    sizes = c(2, 3, 5, 8, 10, 15, 20),
    seed = 1000 + fold_id
  )
  
  selected_feats <- rfe_res$selected_features
  
  all_features[[fold_id]] <- tibble(
    fold_id = fold_id,
    feature = selected_feats,
    n_selected = length(selected_feats)
  )
  
  # final model trained on outer training data only
  final_fit <- train_final_svm_on_outer_train(
    x_train = x_train_scaled[, selected_feats, drop = FALSE],
    y_train = y_train,
    seed = 2000 + fold_id
  )
  
  # predict on held-out outer test fold
  test_prob <- predict(
    final_fit,
    newdata = x_test_scaled[, selected_feats, drop = FALSE],
    type = "prob"
  )[["case"]]
  
  test_pred <- ifelse(test_prob >= 0.5, "case", "control")
  
  pred_df <- tibble(
    fold_id = fold_id,
    sample_id = test_dat[[sample_id_col]],
    observed = y_test,
    predicted_class = factor(test_pred, levels = c("control", "case")),
    predicted_prob = test_prob
  )
  
  all_predictions[[fold_id]] <- pred_df
  
  perf_df <- calc_binary_metrics(
    obs = y_test,
    prob = test_prob,
    positive_class = positive_class
  ) %>%
    mutate(
      fold_id = fold_id,
      n_selected_features = length(selected_feats)
    ) %>%
    relocate(fold_id)
  
  all_performance[[fold_id]] <- perf_df
}

# ----------------------------
# 5. Export results
# ----------------------------
predictions_df <- bind_rows(all_predictions)
features_df    <- bind_rows(all_features)
performance_df <- bind_rows(all_performance)

performance_summary <- performance_df %>%
  summarise(
    mean_AUC = mean(AUC, na.rm = TRUE),
    sd_AUC = sd(AUC, na.rm = TRUE),
    mean_Accuracy = mean(Accuracy, na.rm = TRUE),
    mean_Sensitivity = mean(Sensitivity, na.rm = TRUE),
    mean_Specificity = mean(Specificity, na.rm = TRUE)
  )

write.csv(predictions_df, pred_file, row.names = FALSE)
write.csv(features_df, feat_file, row.names = FALSE)
write.csv(performance_df, perf_file, row.names = FALSE)
write.csv(performance_summary, perf_overall_file, row.names = FALSE)

cat("Saved outer-fold predictions to:", pred_file, "\n")
cat("Saved selected features by fold to:", feat_file, "\n")
cat("Saved fold-wise performance to:", perf_file, "\n")
cat("Saved overall performance summary to:", perf_overall_file, "\n")