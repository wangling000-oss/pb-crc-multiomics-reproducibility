# ============================================================
# Script: 04_fit_final_nomogram.R
# Purpose:
#   Fit a final illustrative nomogram model using features
#   selected stably across nested CV outer folds.
#
# Important note:
#   This script is for final model presentation only.
#   Performance claims should rely on nested CV results,
#   not on this full-dataset nomogram fit.
#
# Input:
#   inputs/ml_input_matrix.csv
#   inputs/ml_labels.csv
#   outputs/selected_features_by_fold.csv
#
# Output:
#   outputs/final_nomogram_feature_frequency.csv
#   outputs/final_nomogram_coefficients.csv
#   outputs/final_nomogram.pdf
#   outputs/final_calibration_plot.pdf
#   outputs/final_dca_plot.pdf
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(tidyverse)
  library(rms)
  library(rmda)
})

# ----------------------------
# 1. Paths
# ----------------------------
expr_file  <- "inputs/ml_input_matrix.csv"
label_file <- "inputs/ml_labels.csv"
expr <- read.csv(expr_file, check.names = FALSE, stringsAsFactors = FALSE)
lab  <- read.csv(label_file, check.names = FALSE, stringsAsFactors = FALSE)
feat_file <- "outputs/selected_features_by_fold.csv"

freq_file <- "outputs/final_nomogram_feature_frequency.csv"
coef_file <- "outputs/final_nomogram_coefficients.csv"
nomo_pdf  <- "outputs/final_nomogram.pdf"
cal_pdf   <- "outputs/final_calibration_plot.pdf"
dca_pdf   <- "outputs/final_dca_plot.pdf"

# ----------------------------
# 2. Read data
# ----------------------------
expr <- read.csv(expr_file, check.names = FALSE, stringsAsFactors = FALSE)
lab  <- read.csv(label_file, check.names = FALSE, stringsAsFactors = FALSE)
feat <- read.csv(feat_file, stringsAsFactors = FALSE)

names(expr)[1] <- "sample_id"
names(lab)[1]  <- "sample_id"
names(lab)[2]  <- "label"

dat <- merge(expr, lab, by = "sample_id")
dat$label <- factor(dat$label, levels = c(0, 1), labels = c("control", "case"))

dat$label_bin <- ifelse(dat$label == "case", 1, 0)

# ----------------------------
# 3. Feature frequency across outer folds
# ----------------------------
feat_freq <- feat %>%
  count(feature, name = "selected_in_n_folds") %>%
  arrange(desc(selected_in_n_folds), feature)

write.csv(feat_freq, freq_file, row.names = FALSE)


final_features <- feat_freq %>%
  filter(selected_in_n_folds >= 3) %>%
  pull(feature)


if (length(final_features) < 2) {
  final_features <- feat_freq %>%
    slice_head(n = min(5, nrow(feat_freq))) %>%
    pull(feature)
}

cat("Final nomogram features:\n")
print(final_features)

# ----------------------------
# 4. Build formula
# ----------------------------
model_dat <- dat %>%
  select(all_of(c("sample_id", "label", "label_bin", final_features)))

form <- as.formula(
  paste("label_bin ~", paste(final_features, collapse = " + "))
)

# ----------------------------
# 5. Fit final logistic model
# ----------------------------
dd <- datadist(model_dat)
options(datadist = "dd")

fit <- lrm(form, data = model_dat, x = TRUE, y = TRUE)

coef_df <- tibble(
  term = names(coef(fit)),
  coefficient = as.numeric(coef(fit))
)

write.csv(coef_df, coef_file, row.names = FALSE)

# ----------------------------
# 6. Nomogram
# ----------------------------
pdf(nomo_pdf, width = 10, height = 7)

nom <- nomogram(
  fit,
  fun = plogis,
  fun.at = c(0.1, 0.3, 0.5, 0.7, 0.9),
  funlabel = "Predicted Risk"
)

plot(nom)

dev.off()

# ----------------------------
# 7. Calibration
# ----------------------------
pdf(cal_pdf, width = 6, height = 6)

cal <- calibrate(fit, method = "boot", B = 1000)
plot(cal, xlab = "Predicted Probability", ylab = "Observed Probability")

dev.off()

# ----------------------------
# 8. Decision curve analysis
# ----------------------------
# rmda 需要 outcome 为 0/1
dca_dat <- model_dat %>%
  select(label_bin, all_of(final_features))

dca_formula <- as.formula(
  paste("label_bin ~", paste(final_features, collapse = " + "))
)

dca_fit <- decision_curve(
  formula = dca_formula,
  data = dca_dat,
  family = binomial(link = "logit"),
  thresholds = seq(0, 1, by = 0.01),
  confidence.intervals = 0.95,
  study.design = "case-control"
)

pdf(dca_pdf, width = 7, height = 6)
plot_decision_curve(
  dca_fit,
  curve.names = "Nomogram model",
  xlab = "Threshold Probability",
  ylab = "Net Benefit",
  standardize = FALSE
)
dev.off()

cat("Saved feature frequency to:", freq_file, "\n")
cat("Saved coefficients to:", coef_file, "\n")
cat("Saved nomogram to:", nomo_pdf, "\n")
cat("Saved calibration plot to:", cal_pdf, "\n")
cat("Saved DCA plot to:", dca_pdf, "\n")