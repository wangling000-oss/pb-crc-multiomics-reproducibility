# ============================================================
# Script: 01_make_splits.R
# Purpose:
#   Create fixed, reproducible outer CV splits for ML analyses
#   using the canonical expression matrix and label file.
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(tidyverse)
})

set.seed(20260315)

# ----------------------------
# 1. Paths
# ----------------------------
expr_file   <- "inputs/ml_input_matrix.csv"
label_file  <- "inputs/ml_labels.csv"
split_file  <- "inputs/reproducible_splits.rds"
summary_file <- "outputs/split_summary.csv"

dir.create("inputs", showWarnings = FALSE, recursive = TRUE)
dir.create("outputs", showWarnings = FALSE, recursive = TRUE)

# ----------------------------
# 2. Read data
# ----------------------------
expr <- read.csv(expr_file, check.names = FALSE, stringsAsFactors = FALSE)
lab  <- read.csv(label_file, check.names = FALSE, stringsAsFactors = FALSE)


names(expr)[1] <- "sample_id"
names(lab)[1]  <- "sample_id"
names(lab)[2]  <- "label"


dat <- merge(expr, lab, by = "sample_id")


dat$label <- factor(dat$label, levels = c(0, 1), labels = c("control", "case"))

# ----------------------------
# 3. Create stratified outer folds
# ----------------------------
make_stratified_folds <- function(y, k = 5, seed = 123) {
  set.seed(seed)
  y <- as.factor(y)
  idx_list <- split(seq_along(y), y)
  
  fold_assign <- integer(length(y))
  
  for (cls in names(idx_list)) {
    cls_idx <- sample(idx_list[[cls]])
    fold_ids <- rep(1:k, length.out = length(cls_idx))
    fold_assign[cls_idx] <- fold_ids
  }
  
  folds <- vector("list", k)
  for (i in seq_len(k)) {
    test_idx  <- which(fold_assign == i)
    train_idx <- setdiff(seq_along(y), test_idx)
    
    folds[[i]] <- list(
      fold_id = i,
      train_index = train_idx,
      test_index = test_idx,
      train_sample_id = dat$sample_id[train_idx],
      test_sample_id = dat$sample_id[test_idx]
    )
  }
  
  folds
}

outer_splits <- make_stratified_folds(
  y = dat$label,
  k = 5,
  seed = 20260315
)

# ----------------------------
# 4. Save split object
# ----------------------------
saveRDS(
  list(
    metadata = list(
      created_on = as.character(Sys.time()),
      seed = 20260315,
      k_outer = 5,
      sample_id_col = "sample_id",
      label_col = "label",
      n_samples = nrow(dat)
    ),
    outer_splits = outer_splits
  ),
  file = split_file
)

# ----------------------------
# 5. Export split summary
# ----------------------------
split_summary <- purrr::map_dfr(outer_splits, function(x) {
  train_y <- dat$label[x$train_index]
  test_y  <- dat$label[x$test_index]
  
  tibble(
    fold_id = x$fold_id,
    n_train = length(x$train_index),
    n_test  = length(x$test_index),
    train_case = sum(train_y == "case"),
    train_control = sum(train_y == "control"),
    test_case = sum(test_y == "case"),
    test_control = sum(test_y == "control")
  )
})

write.csv(split_summary, summary_file, row.names = FALSE)

cat("Saved fixed splits to:", split_file, "\n")
cat("Saved split summary to:", summary_file, "\n")
