# Legacy visualization only; used for candidate-gene identification and illustrative figures.
# Not used for the primary reproducible performance evaluation.
# For candidate-gene identification / visualization only; not the primary reproducible validation pipeline.
#install.packages("rms")
#install.packages("rmda")


library(rms)
library(rmda)
library(limma)


setwd("XXX")

#Read the input file
data=read.table("NM.txt", header=T, sep="\t", check.names=F, row.names=1)
#Convert to matrix
dimnames=list(rownames(data), colnames(data))
data=matrix(as.numeric(as.matrix(data)), nrow=nrow(data), dimnames=dimnames)
#Remove the genes with low expression
data=data[rowMeans(data)>1,]
boxplot(data.frame(data),col="#4DBBD5")
#standardization
data=normalizeBetweenArrays(data)
boxplot(data.frame(data),col="#4DBBD5")
dev.off()

write.table(data.frame(ID=rownames(data),data),file="normalize.txt", sep="\t", quote=F, row.names = F)

#Obtain genes
data = data[c("BCL2","MAPK3","HMOX1","IL1B","ALAD","NLRP3"),]
data=t(data)

Control=read.table("Control.txt", header=F, sep="\t", check.names=F)

Treat=read.table("Treat.txt", header=F, sep="\t", check.names=F)

data = data[c(Control[,1],Treat[,1]),]

#Set group information
conNum=length(rownames(Control))
treatNum=length(rownames(Treat))
group=c(rep("Control",conNum), rep("Treat",treatNum))

#combine
rt=cbind(as.data.frame(data), Type=group)

#settle
ddist=datadist(rt)
options(datadist="ddist")

#The following two parts need to be revised.
paste(colnames(data), collapse="+")

#Build the model
# Pay attention to the "~" character
lrmModel=lrm(Type~ BCL2+MAPK3+HMOX1+IL1B+ALAD+NLRP3, data=rt, x=T, y=T)
nomo=nomogram(lrmModel, fun=plogis,
              fun.at=c(0.001,0.01,0.05,0.3,0.7,0.9,0.99),
              lp=F, funlabel="Risk of Disease")
#nomogram
pdf("Nom.pdf", width=9, height=6)
plot(nomo)
dev.off()

#calibration curve
set.seed(123)
cali=calibrate(lrmModel, method="boot", B=1000)
pdf("Calibration.pdf", width=6, height=6)
plot(cali,
     xlab="Predicted probability",
     ylab="Actual probability", sub=F)
dev.off()

#Decision curve
#Please note that the characters """ and "~" have been modified.
rt$Type=ifelse(rt$Type=="Control", 0, 1)
dc1=decision_curve(Type ~ BCL2+HMOX1+ALAD, data=rt, 
                  family = binomial(link ='logit'),
                  thresholds= seq(0,1,by = 0.01),
                  confidence.intervals = 0.95)
dc2=decision_curve(Type ~ BCL2+HMOX1+ALAD+NLRP3, data=rt, 
                  family = binomial(link ='logit'),
                  thresholds= seq(0,1,by = 0.01),
                  confidence.intervals = 0.95)
dc3=decision_curve(Type ~ BCL2+MAPK3+HMOX1+IL1B+ALAD+NLRP3, data=rt, 
                  family = binomial(link ='logit'),
                  thresholds= seq(0,1,by = 0.01),
                  confidence.intervals = 0.95)

#DCA
pdf(file="DCA.pdf", width=6, height=6)
plot_decision_curve(dc1,dc2,dc3
                    curve.names = c("group~BCL2", "group~BCL2+HMOX1+ALAD+NLRP3", "group~BCL2+MAPK3+HMOX1+IL1B+ALAD+NLRP3"),
                    xlab="Threshold probability",
                    cost.benefit.axis=T,
                    col="#EA9E58","#4198ac","#B6B3D6"
                    confidence.intervals=FALSE,
                    standardize=FALSE)
dev.off()


# Assume that the Type has been correctly converted and it is confirmed that the Type is binary (with values of 0 and 1) 
# Decision Curve
# Please note to modify the characters "" and ~
rt$Type <- ifelse(rt$Type == "Control", 0, 1)

# Check the converted Type
table(rt$Type)

# If the table shows 0 and 1, proceed; otherwise, stop.

# Then calculate the decision curve
dc1 <- decision_curve(Type ~ MAPK3 , 
                      data = rt, 
                      family = binomial(link = 'logit'),
                      thresholds = seq(0, 1, by = 0.01),
                      confidence.intervals = 0.95)

dc2 <- decision_curve(Type ~ MAPK3 + HMOX1 + ALAD, 
                      data = rt, 
                      family = binomial(link = 'logit'),
                      thresholds = seq(0, 1, by = 0.01),
                      confidence.intervals = 0.95)

dc3 <- decision_curve(Type ~ BCL2 + MAPK3 + HMOX1 + IL1B + ALAD + NLRP3, 
                      data = rt, 
                      family = binomial(link = 'logit'),
                      thresholds = seq(0, 1, by = 0.01),
                      confidence.intervals = 0.95)

# DCA
pdf(file = "DCA.pdf", width = 8, height = 9)
plot_decision_curve(list(dc1, dc2, dc3),
                    curve.names = c("Model1", "Model2", "Model3"),
                    xlab = "Threshold probability",
                    cost.benefit.axis = TRUE,
                    col = c("#EA9E58", "#4198ac", "#B6B3D6"),
                    confidence.intervals = FALSE,
                    standardize = FALSE,
                    legend.position = "topright")
dev.off()
