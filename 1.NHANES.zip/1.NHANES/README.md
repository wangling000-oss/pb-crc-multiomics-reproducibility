###NHANES

Main script: `NHANES.R`

This script reproduces the NHANES analysis component of the manuscript, including Table 1 and Table 2 (survey-weighted models), as well as supporting summary files for the flowchart and sensitivity analyses.

To run:
`Rscript 1.NHANES/NHANES.R > 1.NHANES/NHANES_run_log.txt 2>&1`

Main regenerated outputs:
- `Table1_weighted_CRC_vs_nonCRC_flow.docx`
- `Table2_Model1_weighted.csv`
- `Table2_Model2_weighted.csv`
- `Table2_Model3_weighted.csv`
- `Table2_PforTrend_weighted.csv`
- `NHANES_flowchart_counts.csv`
- `Supplement_missing_counts.csv`
- `Sensitivity_unweighted_model3.csv`
- `Sensitivity_weighted_model3.csv`
- `Sensitivity_model3_unknown_category.csv`

Execution log:
- `NHANES_run_log.txt`

Session information:
- `sessionInfo.txt`