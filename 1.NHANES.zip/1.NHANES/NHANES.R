# ============================================================
# Script: 01_nhanes_table1_table2.R
# Purpose:
#   Reproduce the NHANES analyses for:
#   - Table 1 baseline characteristics by CRC status
#   - Table 2 survey-weighted logistic regression models
#   - Flowchart counts
#   - Sensitivity analyses
#   - Missing-value summary
#
# Manuscript sections supported:
#   - Methods: NHANES study population, variable definitions,
#              and statistical analysis
#   - Results: NHANES Table 1, Table 2, and flowchart
#
# Inputs:
#   data_raw/NHANES/*.XPT
#
# Outputs:
#   outputs/tables/*.csv
#   outputs/tables/*.docx
#   outputs/logs/NHANES_run_log.txt
#
# Notes:
#   - This script uses project-relative paths only.
#   - No setwd() call is required.
#   - The analytical content is unchanged; only reproducibility
#     structure, comments, and file paths have been standardized.
# ============================================================
rm(list = ls())

suppressPackageStartupMessages({
  library(tidyverse)
  library(foreign)
  library(survey)
  library(broom)
  library(openxlsx)
  library(tableone)
  library(gtsummary)
  library(gt)
  library(forcats)
  library(here)
})

options(digits = 4)
options(survey.lonely.psu = "adjust")

# =========================================================
# 0. 日志输出（给审稿人看的可重复性证据）
# =========================================================
sink("NHANES_run_log.txt", split = TRUE)
cat("===== NHANES analysis started =====\n")
cat("Time:", as.character(Sys.time()), "\n\n")

# =========================================================
# 1. Read DEMO files
# =========================================================
d_demo_f <- read.xport("DEMO_F.XPT")[, c("SEQN","SDMVPSU","SDMVSTRA","RIAGENDR","RIDAGEYR","RIDRETH1","WTMEC2YR","DMDHREDU","DMDHRMAR","INDFMPIR")]
d_demo_g <- read.xport("DEMO_G.XPT")[, c("SEQN","SDMVPSU","SDMVSTRA","RIAGENDR","RIDAGEYR","RIDRETH1","WTMEC2YR","DMDHREDU","DMDHRMAR","INDFMPIR")]
d_demo_h <- read.xport("DEMO_H.XPT")[, c("SEQN","SDMVPSU","SDMVSTRA","RIAGENDR","RIDAGEYR","RIDRETH1","WTMEC2YR","DMDHREDU","DMDHRMAR","INDFMPIR")]
d_demo_i <- read.xport("DEMO_I.XPT")[, c("SEQN","SDMVPSU","SDMVSTRA","RIAGENDR","RIDAGEYR","RIDRETH1","WTMEC2YR","DMDHREDU","DMDHRMAR","INDFMPIR")]
d_demo_j <- read.xport("DEMO_J.XPT")[, c("SEQN","SDMVPSU","SDMVSTRA","RIAGENDR","RIDAGEYR","RIDRETH1","WTMEC2YR","DMDHREDZ","DMDHRMAZ","INDFMPIR")]

d_demo_j <- d_demo_j %>%
  rename(DMDHREDU = DMDHREDZ,
         DMDHRMAR = DMDHRMAZ)

d_demo_f$Year <- "2009-2010"
d_demo_g$Year <- "2011-2012"
d_demo_h$Year <- "2013-2014"
d_demo_i$Year <- "2015-2016"
d_demo_j$Year <- "2017-2018"

d_demo <- bind_rows(d_demo_f, d_demo_g, d_demo_h, d_demo_i, d_demo_j) %>%
  rename(
    sdmvpsu  = SDMVPSU,
    sdmvstra = SDMVSTRA,
    age      = RIDAGEYR,
    sex      = RIAGENDR,
    eth      = RIDRETH1,
    wtmec2yr = WTMEC2YR,
    edu      = DMDHREDU,
    mar      = DMDHRMAR,
    Income   = INDFMPIR
  ) %>%
  mutate(
    sex = recode(as.character(sex), "1" = "Male", "2" = "Female"),
    eth = recode(as.character(eth),
                 "1" = "Mexican American",
                 "2" = "Other Hispanic",
                 "3" = "Non-Hispanic White",
                 "4" = "Non-Hispanic Black",
                 "5" = "Other race"),
    edu = case_when(
      edu %in% c(1, 2) ~ "Under high school",
      edu == 3 ~ "High school or equivalent",
      edu %in% c(4, 5) ~ "Above high school",
      TRUE ~ NA_character_
    ),
    mar = case_when(
      mar %in% c(1, 6) ~ "Married/Living with partner",
      mar %in% c(2, 3, 4, 5) ~ "Living alone",
      TRUE ~ NA_character_
    ),
    Income = cut(
      Income,
      breaks = c(-Inf, 1.0, 2.9, Inf),
      labels = c("<1.0", "1.0-2.9", ">=3.0"),
      right = TRUE
    ),
    wtmec2yr = wtmec2yr / 5
  )

d_demo_all <- d_demo
d_demo_adult <- d_demo %>% filter(age >= 20)

cat("DEMO total n =", nrow(d_demo_all), "\n")
cat("Adult DEMO n =", nrow(d_demo_adult), "\n\n")

# =========================================================
# 2.  Read blood lead (LBXBPB)
# =========================================================
m1 <- read.xport("PBCD_F.XPT")[, c("SEQN", "LBXBPB")]
m2 <- read.xport("PBCD_G.XPT")[, c("SEQN", "LBXBPB")]
m3 <- read.xport("PBCD_H.XPT")[, c("SEQN", "LBXBPB")]
m4 <- read.xport("PBCD_I.XPT")[, c("SEQN", "LBXBPB")]
m5 <- read.xport("PBCD_J.XPT")[, c("SEQN", "LBXBPB")]

m1$Year <- "2009-2010"
m2$Year <- "2011-2012"
m3$Year <- "2013-2014"
m4$Year <- "2015-2016"
m5$Year <- "2017-2018"

metals <- bind_rows(m1, m2, m3, m4, m5)

# =========================================================
# 3. Read CRC data and construct the unified eligibility set
# =========================================================
d_crc_f <- read.xport("MCQ_F.XPT")[, c("SEQN", "MCQ220", "MCQ230A", "MCQ230B", "MCQ230C")]
d_crc_g <- read.xport("MCQ_G.XPT")[, c("SEQN", "MCQ220", "MCQ230A", "MCQ230B", "MCQ230C")]
d_crc_h <- read.xport("MCQ_H.XPT")[, c("SEQN", "MCQ220", "MCQ230A", "MCQ230B", "MCQ230C")]
d_crc_i <- read.xport("MCQ_I.XPT")[, c("SEQN", "MCQ220", "MCQ230A", "MCQ230B", "MCQ230C")]
d_crc_j <- read.xport("MCQ_J.XPT")[, c("SEQN", "MCQ220", "MCQ230A", "MCQ230B", "MCQ230C")]

d_crc_f$Year <- "2009-2010"
d_crc_g$Year <- "2011-2012"
d_crc_h$Year <- "2013-2014"
d_crc_i$Year <- "2015-2016"
d_crc_j$Year <- "2017-2018"

d_crc_raw <- bind_rows(d_crc_f, d_crc_g, d_crc_h, d_crc_i, d_crc_j) %>%
  mutate(
    crc_questionnaire_missing = ifelse(
      is.na(MCQ220) & is.na(MCQ230A) & is.na(MCQ230B) & is.na(MCQ230C),
      1, 0
    ),
    crc_case = case_when(
      MCQ220 == 1 &
        ((MCQ230A %in% c(16, 31)) |
           (MCQ230B %in% c(16, 31)) |
           (MCQ230C %in% c(16, 31))) ~ "CRC case",
      crc_questionnaire_missing == 1 ~ NA_character_,
      TRUE ~ "Non-case"
    ),
    exclude_other_gi_cancer = ifelse(
      (MCQ230A %in% c(22, 29, 35)) |
        (MCQ230B %in% c(22, 29, 35)) |
        (MCQ230C %in% c(22, 29, 35)),
      1, 0
    )
  )

d_crc_eligible <- d_crc_raw %>%
  filter(crc_questionnaire_missing == 0, exclude_other_gi_cancer == 0) %>%
  select(SEQN, Year, crc_case)

# =========================================================
# 4. Read BMI
# =========================================================
d_bmi_f <- read.xport("BMX_F.XPT")[, c("SEQN","BMXBMI")]
d_bmi_g <- read.xport("BMX_G.XPT")[, c("SEQN","BMXBMI")]
d_bmi_h <- read.xport("BMX_H.XPT")[, c("SEQN","BMXBMI")]
d_bmi_i <- read.xport("BMX_I.XPT")[, c("SEQN","BMXBMI")]
d_bmi_j <- read.xport("BMX_J.XPT")[, c("SEQN","BMXBMI")]

d_bmi_f$Year <- "2009-2010"
d_bmi_g$Year <- "2011-2012"
d_bmi_h$Year <- "2013-2014"
d_bmi_i$Year <- "2015-2016"
d_bmi_j$Year <- "2017-2018"

d_bmi <- bind_rows(d_bmi_f, d_bmi_g, d_bmi_h, d_bmi_i, d_bmi_j) %>%
  rename(bmi = BMXBMI)

# =========================================================
# 5. Read smoking status
# =========================================================
d_smoke_f <- read.xport("SMQ_F.XPT")[, c("SEQN","SMQ020")]
d_smoke_g <- read.xport("SMQ_G.XPT")[, c("SEQN","SMQ020")]
d_smoke_h <- read.xport("SMQ_H.XPT")[, c("SEQN","SMQ020")]
d_smoke_i <- read.xport("SMQ_I.XPT")[, c("SEQN","SMQ020")]
d_smoke_j <- read.xport("SMQ_J.XPT")[, c("SEQN","SMQ020")]

d_smoke_f$Year <- "2009-2010"
d_smoke_g$Year <- "2011-2012"
d_smoke_h$Year <- "2013-2014"
d_smoke_i$Year <- "2015-2016"
d_smoke_j$Year <- "2017-2018"

d_smoke <- bind_rows(d_smoke_f, d_smoke_g, d_smoke_h, d_smoke_i, d_smoke_j) %>%
  mutate(
    smoking = case_when(
      SMQ020 == 1 ~ "Yes",
      SMQ020 == 2 ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, smoking)

# =========================================================
# 6. Read alcohol-use status
# =========================================================
d_alq_f <- read.xport("ALQ_F.XPT")[, c("SEQN","ALQ101")]
d_alq_g <- read.xport("ALQ_G.XPT")[, c("SEQN","ALQ101")]
d_alq_h <- read.xport("ALQ_H.XPT")[, c("SEQN","ALQ101")]
d_alq_i <- read.xport("ALQ_I.XPT")[, c("SEQN","ALQ101")]
d_alq_j <- read.xport("ALQ_J.XPT")[, c("SEQN","ALQ111")]

d_alq_f$Year <- "2009-2010"
d_alq_g$Year <- "2011-2012"
d_alq_h$Year <- "2013-2014"
d_alq_i$Year <- "2015-2016"
d_alq_j$Year <- "2017-2018"

d_alq_1 <- bind_rows(d_alq_f, d_alq_g, d_alq_h, d_alq_i) %>%
  mutate(
    drinking = case_when(
      ALQ101 == 1 ~ "Yes",
      ALQ101 == 2 ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, drinking)

d_alq_2 <- d_alq_j %>%
  mutate(
    drinking = case_when(
      ALQ111 == 1 ~ "Yes",
      ALQ111 == 2 ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, drinking)

d_alq <- bind_rows(d_alq_1, d_alq_2)

# =========================================================
# 7. Read hypertension
# =========================================================
d_bp1_f <- read.xport("BPX_F.XPT")[, c("SEQN", "BPXSY1", "BPXDI1")]
d_bp1_g <- read.xport("BPX_G.XPT")[, c("SEQN", "BPXSY1", "BPXDI1")]
d_bp1_h <- read.xport("BPX_H.XPT")[, c("SEQN", "BPXSY1", "BPXDI1")]
d_bp1_i <- read.xport("BPX_I.XPT")[, c("SEQN", "BPXSY1", "BPXDI1")]
d_bp1_j <- read.xport("BPX_J.XPT")[, c("SEQN", "BPXSY1", "BPXDI1")]

d_bp2_f <- read.xport("BPQ_F.XPT")[, c("SEQN", "BPQ020")]
d_bp2_g <- read.xport("BPQ_G.XPT")[, c("SEQN", "BPQ020")]
d_bp2_h <- read.xport("BPQ_H.XPT")[, c("SEQN", "BPQ020")]
d_bp2_i <- read.xport("BPQ_I.XPT")[, c("SEQN", "BPQ020")]
d_bp2_j <- read.xport("BPQ_J.XPT")[, c("SEQN", "BPQ020")]

d_bp1_f$Year <- "2009-2010"; d_bp1_g$Year <- "2011-2012"; d_bp1_h$Year <- "2013-2014"; d_bp1_i$Year <- "2015-2016"; d_bp1_j$Year <- "2017-2018"
d_bp2_f$Year <- "2009-2010"; d_bp2_g$Year <- "2011-2012"; d_bp2_h$Year <- "2013-2014"; d_bp2_i$Year <- "2015-2016"; d_bp2_j$Year <- "2017-2018"

d_bp1 <- bind_rows(d_bp1_f, d_bp1_g, d_bp1_h, d_bp1_i, d_bp1_j)
d_bp2 <- bind_rows(d_bp2_f, d_bp2_g, d_bp2_h, d_bp2_i, d_bp2_j)

d_bp <- left_join(d_bp1, d_bp2, by = c("SEQN","Year")) %>%
  mutate(
    hypertension = case_when(
      BPXSY1 >= 140 | BPXDI1 >= 90 | BPQ020 == 1 ~ "Yes",
      (!is.na(BPXSY1) | !is.na(BPXDI1) | !is.na(BPQ020)) ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, hypertension)

# =========================================================
# 8. Read hyperlipidemia
# =========================================================
d_high_f <- read.xport("TCHOL_F.XPT")[, c("SEQN", "LBXTC")]
d_high_g <- read.xport("TCHOL_G.XPT")[, c("SEQN", "LBXTC")]
d_high_h <- read.xport("TCHOL_H.XPT")[, c("SEQN", "LBXTC")]
d_high_i <- read.xport("TCHOL_I.XPT")[, c("SEQN", "LBXTC")]
d_high_j <- read.xport("TCHOL_J.XPT")[, c("SEQN", "LBXTC")]

d_high_f$Year <- "2009-2010"
d_high_g$Year <- "2011-2012"
d_high_h$Year <- "2013-2014"
d_high_i$Year <- "2015-2016"
d_high_j$Year <- "2017-2018"

d_high <- bind_rows(d_high_f, d_high_g, d_high_h, d_high_i, d_high_j) %>%
  mutate(
    high = case_when(
      LBXTC > 240 ~ "Yes",
      !is.na(LBXTC) ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, high)

# =========================================================
# 9. Read diabetes
# =========================================================
d_dia1_f <- read.xport("DIQ_F.XPT")[, c("SEQN", "DIQ010")]
d_dia1_g <- read.xport("DIQ_G.XPT")[, c("SEQN", "DIQ010")]
d_dia1_h <- read.xport("DIQ_H.XPT")[, c("SEQN", "DIQ010")]
d_dia1_i <- read.xport("DIQ_I.XPT")[, c("SEQN", "DIQ010")]
d_dia1_j <- read.xport("DIQ_J.XPT")[, c("SEQN", "DIQ010")]

d_dia2_f <- read.xport("GHB_F.XPT")[, c("SEQN", "LBXGH")]
d_dia2_g <- read.xport("GHB_G.XPT")[, c("SEQN", "LBXGH")]
d_dia2_h <- read.xport("GHB_H.XPT")[, c("SEQN", "LBXGH")]
d_dia2_i <- read.xport("GHB_I.XPT")[, c("SEQN", "LBXGH")]
d_dia2_j <- read.xport("GHB_J.XPT")[, c("SEQN", "LBXGH")]

d_dia1_f$Year <- "2009-2010"
d_dia1_g$Year <- "2011-2012"
d_dia1_h$Year <- "2013-2014"
d_dia1_i$Year <- "2015-2016"
d_dia1_j$Year <- "2017-2018"

d_dia2_f$Year <- "2009-2010"
d_dia2_g$Year <- "2011-2012"
d_dia2_h$Year <- "2013-2014"
d_dia2_i$Year <- "2015-2016"
d_dia2_j$Year <- "2017-2018"

d_dia1 <- bind_rows(d_dia1_f, d_dia1_g, d_dia1_h, d_dia1_i, d_dia1_j)
d_dia2 <- bind_rows(d_dia2_f, d_dia2_g, d_dia2_h, d_dia2_i, d_dia2_j)

d_dia <- left_join(d_dia1, d_dia2, by = c("SEQN","Year")) %>%
  mutate(
    diabetes = case_when(
      DIQ010 == 1 | LBXGH >= 6.5 ~ "Yes",
      DIQ010 == 2 & !is.na(LBXGH) & LBXGH < 6.5 ~ "No",
      DIQ010 == 2 & is.na(LBXGH) ~ "No",
      is.na(DIQ010) & !is.na(LBXGH) & LBXGH < 6.5 ~ "No",
      TRUE ~ NA_character_
    )
  ) %>%
  select(SEQN, Year, diabetes)

# =========================================================
# 10. Merge the main analytic dataset
# =========================================================
d <- d_demo_adult %>%
  inner_join(metals, by = c("SEQN","Year")) %>%
  inner_join(d_crc_eligible, by = c("SEQN","Year")) %>%
  left_join(d_bmi,   by = c("SEQN","Year")) %>%
  left_join(d_smoke, by = c("SEQN","Year")) %>%
  left_join(d_alq,   by = c("SEQN","Year")) %>%
  left_join(d_bp,    by = c("SEQN","Year")) %>%
  left_join(d_high,  by = c("SEQN","Year")) %>%
  left_join(d_dia,   by = c("SEQN","Year"))

d <- d %>%
  mutate(
    crc_case = factor(crc_case, levels = c("Non-case","CRC case")),
    sex = factor(sex),
    eth = factor(eth),
    edu = factor(edu),
    mar = factor(mar),
    Income = factor(Income),
    smoking = factor(smoking, levels = c("No", "Yes")),
    drinking = factor(drinking, levels = c("No", "Yes")),
    hypertension = factor(hypertension, levels = c("No", "Yes")),
    high = factor(high, levels = c("No", "Yes")),
    diabetes = factor(diabetes, levels = c("No", "Yes"))
  )

cat("Merged analytic dataset n =", nrow(d), "\n")
cat("CRC cases:\n")
print(table(d$crc_case, useNA = "ifany"))

cat("\nMissing crc_case in analytic dataset:\n")
print(sum(is.na(d$crc_case)))

cat("\nMissing counts for covariates:\n")
print(colSums(is.na(d[, c("age","sex","eth","edu","mar","Income","bmi",
                          "smoking","drinking","hypertension","high","diabetes","LBXBPB","crc_case")])))

# =========================================================
# 11. Survey design object
# =========================================================
nhs <- svydesign(
  data = d,
  ids = ~sdmvpsu,
  strata = ~sdmvstra,
  weights = ~wtmec2yr,
  nest = TRUE
)

# =========================================================
# 12. Blood lead quartiles
# =========================================================
qs_pb <- quantile(d$LBXBPB, probs = c(0.25, 0.50, 0.75), na.rm = TRUE)

d <- d %>%
  mutate(
    PB_Q4 = cut(
      LBXBPB,
      breaks = c(-Inf, qs_pb[1], qs_pb[2], qs_pb[3], Inf),
      labels = c("Q1","Q2","Q3","Q4"),
      include.lowest = TRUE,
      right = TRUE
    ),
    PB_Q4 = factor(PB_Q4, levels = c("Q1","Q2","Q3","Q4")),
    PB_Q4_num = as.numeric(PB_Q4)
  )

nhs <- update(nhs, PB_Q4 = d$PB_Q4, PB_Q4_num = d$PB_Q4_num)

cat("\nLead quartiles:\n")
print(qs_pb)
cat("\nPB_Q4 counts:\n")
print(table(d$PB_Q4, useNA = "ifany"))

# =========================================================
# 13. Table 1
# =========================================================
vars_table1 <- c("age","sex","eth","edu","mar","Income","bmi",
                 "smoking","drinking","hypertension","high","diabetes","LBXBPB")
cat_vars <- c("sex","eth","edu","mar","Income","smoking","drinking","hypertension","high","diabetes")

table1 <- svyCreateTableOne(
  vars = vars_table1,
  strata = "crc_case",
  data = nhs,
  factorVars = cat_vars,
  includeNA = FALSE,
  test = TRUE
)

print(table1, quote = FALSE, noSpaces = TRUE)

table1_mat <- print(table1, quote = FALSE, noSpaces = TRUE, printToggle = FALSE)
write.csv(as.data.frame(table1_mat), "Table1_weighted_CRC_vs_nonCRC.csv", row.names = TRUE)

# =========================================================
# 13.1 Table 1 formatted version based on d_flow_analysis2 / nhs_flow
# =========================================================

vars_table1 <- c(
  "age","sex","eth","edu","mar","Income","bmi",
  "smoking","drinking","hypertension","high","diabetes","LBXBPB"
)

# Create the dataset used for the formatted Table 1
d_flow_analysis <- d %>%
  filter(!is.na(LBXBPB), age >= 20)

# Check whether required variables are present
missing_vars <- setdiff(
  c("crc_case", "sdmvpsu", "sdmvstra", "wtmec2yr", vars_table1),
  names(d_flow_analysis)
)
print(missing_vars)

# Check counts
cat("\nCheck d_flow_analysis counts:\n")
print(table(d_flow_analysis$crc_case, useNA = "ifany"))
cat("nrow(d_flow_analysis) =", nrow(d_flow_analysis), "\n")

nhs_flow <- svydesign(
  data = d_flow_analysis,
  ids = ~sdmvpsu,
  strata = ~sdmvstra,
  weights = ~I(wtmec2yr / 5),
  nest = TRUE
)
# Check counts
cat("\nCheck nhs_flow counts:\n")
print(table(nhs_flow$variables$crc_case, useNA = "ifany"))
cat("nrow(nhs_flow$variables) =", nrow(nhs_flow$variables), "\n")


n_all <- nrow(nhs_flow$variables)
n_non <- sum(nhs_flow$variables$crc_case == "Non-case", na.rm = TRUE)
n_crc <- sum(nhs_flow$variables$crc_case == "CRC case", na.rm = TRUE)


table1_pretty <- tbl_svysummary(
  nhs_flow,
  by = crc_case,
  include = all_of(vars_table1),
  statistic = list(
    all_continuous() ~ "{mean} ± {sd}",
    all_categorical() ~ "{n_unweighted} ({p}%)"
  ),
  digits = list(
    all_continuous() ~ 2,
    all_categorical() ~ c(0, 2)
  ),
  percent = "column",
  missing = "no",
  label = list(
    age ~ "Age, years",
    sex ~ "Sex",
    eth ~ "Race or ethnicity",
    edu ~ "Education",
    mar ~ "Marital status",
    Income ~ "Poverty-income ratio",
    bmi ~ "BMI, kg/m²",
    smoking ~ "Smoking",
    drinking ~ "Drinking",
    hypertension ~ "Hypertension",
    high ~ "Hyperlipidemia",
    diabetes ~ "Diabetes",
    LBXBPB ~ "Blood lead, µg/dL"
  )
) %>%
  add_overall(last = FALSE) %>%
  add_p(pvalue_fun = ~ style_pvalue(.x, digits = 3)) %>%
  modify_header(
    label ~ "**Characteristics**",
    stat_0 ~ paste0("**Overall (N = ", n_all, ")**"),
    stat_1 ~ paste0("**Non-case (n = ", n_non, ")**"),
    stat_2 ~ paste0("**CRC case (n = ", n_crc, ")**"),
    p.value ~ "**p value**"
  ) %>%
  bold_labels() %>%
  italicize_levels()


table1_gt <- as_gt(table1_pretty) %>%
  cols_align(
    align = "center",
    columns = -label
  ) %>%
  tab_source_note(
    source_note = md(
      "Values are presented as weighted mean ± SD for continuous variables and unweighted n (weighted %) for categorical variables. P values were obtained using survey-weighted tests."
    )
  ) %>%
  tab_options(
    table.font.size = px(16),
    data_row.padding = px(6)
  )

table1_gt
gtsave(table1_gt, "Table1_weighted_CRC_vs_nonCRC_flow.docx")
# =========================================================
# 14. Main models
# =========================================================
vars_m3 <- c("crc_case","PB_Q4","PB_Q4_num","age","sex","eth","edu","mar","Income",
             "bmi","smoking","drinking","hypertension","high","diabetes")

d_m3 <- d %>%
  select(all_of(vars_m3), sdmvpsu, sdmvstra, wtmec2yr, LBXBPB) %>%
  na.omit()

cat("\nFinal complete-case sample for Model 3 =", nrow(d_m3), "\n")

nhs_m3 <- svydesign(
  data = d_m3,
  ids = ~sdmvpsu,
  strata = ~sdmvstra,
  weights = ~wtmec2yr,
  nest = TRUE
)

model1 <- svyglm(crc_case ~ PB_Q4, design = nhs_m3, family = quasibinomial())
model2 <- svyglm(crc_case ~ PB_Q4 + sex + eth, design = nhs_m3, family = quasibinomial())
model3 <- svyglm(crc_case ~ PB_Q4 + sex + eth + age + edu + mar + Income +
                   bmi + smoking + drinking + hypertension + high + diabetes,
                 design = nhs_m3, family = quasibinomial())

tidy_or <- function(fit) {
  broom::tidy(fit) %>%
    mutate(
      OR  = exp(estimate),
      LCL = exp(estimate - 1.96 * std.error),
      UCL = exp(estimate + 1.96 * std.error)
    ) %>%
    select(term, estimate, std.error, statistic, p.value, OR, LCL, UCL)
}

res_m1 <- tidy_or(model1)
res_m2 <- tidy_or(model2)
res_m3 <- tidy_or(model3)

cat("\nModel 1 results:\n")
print(res_m1)
cat("\nModel 2 results:\n")
print(res_m2)
cat("\nModel 3 results:\n")
print(res_m3)

write.csv(res_m1, "Table2_Model1_weighted.csv", row.names = FALSE)
write.csv(res_m2, "Table2_Model2_weighted.csv", row.names = FALSE)
write.csv(res_m3, "Table2_Model3_weighted.csv", row.names = FALSE)

# =========================================================
# 15. P for trend
# =========================================================
model1_trend <- svyglm(crc_case ~ PB_Q4_num, design = nhs_m3, family = quasibinomial())
model2_trend <- svyglm(crc_case ~ PB_Q4_num + sex + eth, design = nhs_m3, family = quasibinomial())
model3_trend <- svyglm(crc_case ~ PB_Q4_num + age + sex + eth + edu + mar + Income +
                         bmi + smoking + drinking + hypertension + high + diabetes,
                       design = nhs_m3, family = quasibinomial())

trend_tab <- tibble(
  Model = c("Model 1", "Model 2", "Model 3"),
  P_for_trend = c(
    coef(summary(model1_trend))["PB_Q4_num", "Pr(>|t|)"],
    coef(summary(model2_trend))["PB_Q4_num", "Pr(>|t|)"],
    coef(summary(model3_trend))["PB_Q4_num", "Pr(>|t|)"]
  )
)

cat("\nP for trend:\n")
print(trend_tab)
write.csv(trend_tab, "Table2_PforTrend_weighted.csv", row.names = FALSE)

# =========================================================
# 16. Sensitivity analysis 1: unweighted vs weighted
# =========================================================
glm1 <- glm(crc_case ~ PB_Q4, data = d_m3, family = binomial())
glm2 <- glm(crc_case ~ PB_Q4 + sex + eth, data = d_m3, family = binomial())
glm3 <- glm(crc_case ~ PB_Q4 + age + sex + eth + edu + mar + Income +
              bmi + smoking + drinking + hypertension + high + diabetes,
            data = d_m3, family = binomial())

write.csv(tidy_or(model3), "Sensitivity_weighted_model3.csv", row.names = FALSE)
write.csv(tidy_or(glm3),   "Sensitivity_unweighted_model3.csv", row.names = FALSE)

# =========================================================
# 17. Flowchart counts
# =========================================================
n_total_nhanes <- nrow(d_demo_all)

n_missing_crc <- d_crc_raw %>%
  filter(crc_questionnaire_missing == 1) %>%
  nrow()

n_excluded_other_gi <- d_crc_raw %>%
  filter(exclude_other_gi_cancer == 1) %>%
  nrow()

n_crc_eligible <- nrow(d_crc_eligible)

d_crc_lead <- d_crc_eligible %>%
  inner_join(d_demo_all %>% select(SEQN, Year, age), by = c("SEQN", "Year")) %>%
  left_join(metals, by = c("SEQN", "Year"))

n_missing_blood_lead <- d_crc_lead %>%
  filter(is.na(LBXBPB)) %>%
  nrow()

n_crc_with_lead <- d_crc_lead %>%
  filter(!is.na(LBXBPB)) %>%
  nrow()

n_excluded_age_lt20 <- d_crc_lead %>%
  filter(!is.na(LBXBPB), age < 20) %>%
  nrow()

n_adult_crc_lead <- d_crc_lead %>%
  filter(!is.na(LBXBPB), age >= 20) %>%
  nrow()

n_final_model3 <- nrow(d_m3)

cat("\nAdult participants with eligible CRC data and blood lead =", n_adult_crc_lead, "\n")
cat("Final analytic sample for Model 3 complete-case =", n_final_model3, "\n")

flow_summary <- tibble(
  Step = c(
    "Participants of NHANES 2009-2018",
    "Excluded: missing CRC questionnaire data",
    "Excluded: other GI cancers",
    "Participants eligible for CRC classification",
    "Excluded: missing blood lead test results",
    "Participants with eligible CRC data and blood lead measurement",
    "Excluded: age <20 years",
    "Final analytic sample (Model 3 complete-case)"
  ),
  N = c(
    n_total_nhanes,
    n_missing_crc,
    n_excluded_other_gi,
    n_crc_eligible,
    n_missing_blood_lead,
    n_crc_with_lead,
    n_excluded_age_lt20,
    n_final_model3
  )
)

print(flow_summary)
write.csv(flow_summary, "NHANES_flowchart_counts.csv", row.names = FALSE)

# =========================================================
# 18. Sensitivity analysis 2: treat missing smoking/drinking as Unknown
# =========================================================
d_sens <- d %>%
  mutate(
    smoking3  = fct_explicit_na(smoking,  na_level = "Unknown"),
    drinking3 = fct_explicit_na(drinking, na_level = "Unknown")
  )

vars_sens <- c("crc_case","PB_Q4","age","sex","eth","edu","mar","Income",
               "bmi","smoking3","drinking3","hypertension","high","diabetes")

d_sens_cc <- d_sens %>%
  select(all_of(vars_sens), sdmvpsu, sdmvstra, wtmec2yr) %>%
  na.omit()

nhs_sens <- svydesign(
  data = d_sens_cc,
  ids = ~sdmvpsu,
  strata = ~sdmvstra,
  weights = ~wtmec2yr,
  nest = TRUE
)

model3_sens_unknown <- svyglm(
  crc_case ~ PB_Q4 + age + sex + eth + edu + mar + Income +
    bmi + smoking3 + drinking3 + hypertension + high + diabetes,
  design = nhs_sens,
  family = quasibinomial()
)

write.csv(tidy_or(model3_sens_unknown), "Sensitivity_model3_unknown_category.csv", row.names = FALSE)

# =========================================================
# 19. Missing counts
# =========================================================
missing_summary <- tibble(
  variable = c("smoking", "drinking", "diabetes", "bmi", "hypertension", "high"),
  missing_n = c(
    sum(is.na(d$smoking)),
    sum(is.na(d$drinking)),
    sum(is.na(d$diabetes)),
    sum(is.na(d$bmi)),
    sum(is.na(d$hypertension)),
    sum(is.na(d$high))
  )
)

write.csv(missing_summary, "Supplement_missing_counts.csv", row.names = FALSE)
print(missing_summary)

# =========================================================
# 20. sessionInfo
# =========================================================
cat("\n===== sessionInfo() =====\n")
print(sessionInfo())

cat("\n===== NHANES analysis finished =====\n")
sink()

